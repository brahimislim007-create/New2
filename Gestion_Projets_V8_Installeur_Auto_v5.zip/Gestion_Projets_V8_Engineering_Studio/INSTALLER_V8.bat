@echo off
setlocal
cd /d "%~dp0"
title Installation Gestion Projets V8
echo ================================================
echo   GESTION PROJETS V8 ENGINEERING STUDIO
echo ================================================
set "PY="
call :find_system_python
if not defined PY (
  echo Installez d'abord Python 3.12 ou 3.13 en version 64 bits ^(Windows x86-64^).
  echo Telechargement : https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
echo Python utilise : %PY%

if not exist ".env" (
  copy /Y ".env.example" ".env" >nul
  echo Configurez maintenant PostgreSQL et le mot de passe admin dans .env.
  notepad .env
)

if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv
  if errorlevel 1 goto error
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error
python scripts\verify_code.py
if errorlevel 1 goto error

echo.
echo Installation terminee. Lancez LANCER_GESTION_PROJETS_V8.bat
pause
exit /b 0

:error
echo Une erreur est survenue pendant l'installation.
pause
exit /b 1

:find_system_python
py -3.13 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.13"
  goto :eof
)
py -3.12 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.12"
  goto :eof
)
python -c "import struct,sys; sys.exit(0 if (sys.version_info[:2] in ((3,12),(3,13)) and struct.calcsize('P')==8) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=python"
goto :eof
