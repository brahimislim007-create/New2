@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ==========================================
echo GESTION PROJETS V8 - BUILD WINDOWS x64 COMPLET
echo ==========================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_BUILD_TOOLS.ps1"
if errorlevel 1 (
  echo [ERREUR] Preparation des outils impossible.
  pause
  exit /b 1
)
call "%~dp0build_exe.bat"
if errorlevel 1 exit /b 1
call "%~dp0build_setup.bat"
if errorlevel 1 exit /b 1
exit /b 0
