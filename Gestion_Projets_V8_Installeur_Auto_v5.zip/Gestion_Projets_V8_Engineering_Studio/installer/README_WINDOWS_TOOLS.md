# Installation automatique des outils Windows

## Le plus simple

1. Ouvrez le dossier du projet.
2. Double-cliquez sur :

`CREER_SETUP_WINDOWS.bat`

Le script tente automatiquement de :

- détecter Python ;
- installer Python via `winget` si nécessaire ;
- installer `pip` et les dépendances Python ;
- installer `PyInstaller` ;
- détecter Inno Setup ;
- installer Inno Setup via `winget` si nécessaire ;
- rechercher automatiquement `ISCC.exe` ;
- créer l'application `.exe` ;
- créer `Gestion_Projets_V7_Setup.exe`.

## Fichiers importants

- `INSTALL_WINDOWS_BUILD_TOOLS.bat` : prépare les outils uniquement.
- `installer/INSTALL_BUILD_TOOLS.ps1` : installation/détection automatique.
- `installer/BUILD_ALL_WINDOWS.bat` : construction complète.
- `installer/Gestion_Projets_V7_Setup.iss` : configuration Inno Setup.

## Remarque

Une connexion Internet peut être nécessaire pour télécharger Python, PyInstaller
ou Inno Setup. Windows doit disposer de `winget` pour l'installation automatique.
Sinon, le script indique clairement l'outil manquant.

Pour exécuter les scripts PowerShell, le projet utilise uniquement une autorisation
temporaire pour ce processus (`-ExecutionPolicy Bypass`) et ne modifie pas
permanemment la politique PowerShell du système.
