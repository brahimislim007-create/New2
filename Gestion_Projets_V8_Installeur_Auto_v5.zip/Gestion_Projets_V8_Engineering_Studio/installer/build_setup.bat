@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo CREATION DU SETUP WINDOWS V8
echo ==========================================
if not exist "..\dist\Gestion Projets V8 Engineering Studio\Gestion Projets V8 Engineering Studio.exe" (
 echo EXE introuvable. Executez d'abord build_exe.bat.
 pause
 exit /b 1
)
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC (
 echo Inno Setup 6 introuvable. Installez-le ou lancez INSTALL_BUILD_TOOLS.ps1.
 pause
 exit /b 1
)
"%ISCC%" "Gestion_Projets_V8_Setup.iss"
if errorlevel 1 goto error
echo Setup genere dans installer\Output\Gestion_Projets_V8_Setup.exe
pause
exit /b 0
:error
echo ECHEC DE CREATION DU SETUP.
pause
exit /b 1
