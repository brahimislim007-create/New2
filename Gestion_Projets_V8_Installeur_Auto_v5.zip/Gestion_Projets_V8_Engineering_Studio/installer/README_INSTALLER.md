# Création de l'installateur Windows

## Objectif

Créer un installateur Windows :

`Gestion_Projets_V7_Setup.exe`

L'utilisateur final pourra installer et lancer le programme sans ouvrir
Visual Studio ou la console Python.

## Étape 1 — Créer l'application EXE

Exécuter :

`installer\\build_exe.bat`

Le script :

1. crée/utilise `.venv` ;
2. installe les dépendances ;
3. installe PyInstaller ;
4. vérifie le code ;
5. génère l'application Windows.

Résultat :

`dist\\Gestion Projets V7\\Gestion Projets V7.exe`

## Étape 2 — Créer Setup.exe

Installer Inno Setup sur le poste de compilation.

Puis exécuter :

`installer\\build_setup.bat`

Ou ouvrir :

`installer\\Gestion_Projets_V7_Setup.iss`

dans Inno Setup Compiler puis cliquer **Compile**.

## Résultat

`installer\\Output\\Gestion_Projets_V7_Setup.exe`

## Compilation complète

Exécuter :

`installer\\BUILD_ALL.bat`

### Important

La compilation d'un vrai `.exe` Windows nécessite Windows et les outils
PyInstaller/Inno Setup installés. Cette archive contient les scripts et la
configuration nécessaires, mais le `.exe` final doit être compilé sur un
environnement Windows compatible.
