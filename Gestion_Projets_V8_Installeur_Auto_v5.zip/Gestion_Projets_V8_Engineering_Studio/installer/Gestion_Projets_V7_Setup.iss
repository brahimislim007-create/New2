#define MyAppName "Gestion Projets V7 Studio"
#define MyAppVersion "7.0"
#define MyAppPublisher "Gestion Projets"
#define MyAppExeName "Gestion Projets V7.exe"

[Setup]
AppId={{8E2B4B4D-7A61-4D71-9C7A-9F1E8F0B7A77}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Gestion Projets V7 Studio
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=Gestion_Projets_V7_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=lowest

[Files]
Source: "..\dist\Gestion Projets V7\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis supplémentaires:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Lancer {#MyAppName}"; Flags: nowait postinstall skipifsilent
