﻿
$ErrorActionPreference = "Stop"

Write-Host "=========================================="
Write-Host " GESTION PROJETS V8 - OUTILS DE COMPILATION (Windows x64)"
Write-Host "=========================================="

function Test-Command($Name) {
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

# Python
if (-not (Test-Command "python")) {
    Write-Host "[INFO] Python introuvable."
    if (Test-Command "winget") {
        Write-Host "[INFO] Installation de Python..."
        winget install --id Python.Python.3.12 -e --architecture x64 --accept-package-agreements --accept-source-agreements
    } else {
        throw "Python introuvable et winget indisponible. Installez Python puis relancez ce script."
    }
}

# Refresh common Python launcher usage
if (-not (Test-Command "py") -and -not (Test-Command "python")) {
    throw "Python n'est toujours pas disponible. Fermez et rouvrez le terminal Windows."
}

# Inno Setup
$possibleISCC = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 6\ISCC.exe",
    "${env:LOCALAPPDATA}\Programs\Inno Setup 6\ISCC.exe"
)

$ISCC = $possibleISCC | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $ISCC) {
    Write-Host "[INFO] Inno Setup introuvable."
    if (Test-Command "winget") {
        Write-Host "[INFO] Installation de Inno Setup..."
        winget install --id JRSoftware.InnoSetup -e --architecture x64 --accept-package-agreements --accept-source-agreements
    } else {
        throw "Inno Setup introuvable et winget indisponible."
    }

    $ISCC = $possibleISCC | Where-Object { Test-Path $_ } | Select-Object -First 1
}

if (-not $ISCC) {
    Write-Warning "Installation terminée, mais ISCC.exe n'a pas encore été détecté."
    Write-Warning "Fermez/réouvrez PowerShell puis relancez BUILD_ALL.bat."
} else {
    Write-Host "[OK] Inno Setup: $ISCC"
}

# Python dependencies
$PythonExe = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $PythonExe) {
    $PythonExe = "py"
}

Write-Host "[INFO] Mise à jour de pip..."
& $PythonExe -m pip install --upgrade pip

Write-Host "[INFO] Installation des outils Python..."
& $PythonExe -m pip install pyinstaller

Write-Host ""
# Vérifie que Python est bien 64 bits (requis pour PySide6/PyInstaller ici)
$bits = & $PythonExe -c "import struct; print(struct.calcsize('P')*8)"
if ($bits -ne "64") { throw "Python 32 bits détecté ($bits bits). Installez Python 64 bits (Windows x86-64)." }

Write-Host "[OK] Environnement de compilation prêt (Python 64 bits)."
