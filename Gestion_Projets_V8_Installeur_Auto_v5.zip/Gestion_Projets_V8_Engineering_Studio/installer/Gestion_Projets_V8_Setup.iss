#define MyAppName "Gestion Projets V8 Engineering Studio"
#define MyAppVersion "8.0.0"
#define MyAppPublisher "Gestion Projets"
#define MyAppExeName "Gestion Projets V8 Engineering Studio.exe"

[Setup]
AppId={{8E2B4B4D-7A61-4D71-9C7A-9F1E8F0B7A78}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Gestion Projets V8 Engineering Studio
DefaultGroupName={#MyAppName}
OutputDir=Output
OutputBaseFilename=Gestion_Projets_V8_Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=lowest

[Files]
Source: "..\dist\Gestion Projets V8 Engineering Studio\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis supplémentaires:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Lancer {#MyAppName}"; Flags: nowait postinstall skipifsilent
