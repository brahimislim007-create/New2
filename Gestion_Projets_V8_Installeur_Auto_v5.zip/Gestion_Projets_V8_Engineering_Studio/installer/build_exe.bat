@echo off
setlocal
cd /d "%~dp0\.."
echo ==========================================
echo BUILD GESTION PROJETS V8 - EXE (Windows x64)
echo ==========================================
set "PY="
call :find_system_python
if not defined PY (
  echo ERREUR: Python 3.12 ou 3.13 64 bits introuvable.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv
  if errorlevel 1 goto error
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error
python scripts\verify_code.py
if errorlevel 1 goto error

pyinstaller --noconfirm --clean --windowed --onedir ^
 --name "Gestion Projets V8 Engineering Studio" ^
 --collect-all PySide6 ^
 --hidden-import psycopg ^
 --add-data "app;app" ^
 main.py
if errorlevel 1 goto error
copy /Y ".env.example" "dist\Gestion Projets V8 Engineering Studio\.env.example" >nul

echo EXE compile dans dist\Gestion Projets V8 Engineering Studio
pause
exit /b 0

:error
echo ECHEC DE LA COMPILATION EXE.
pause
exit /b 1

:find_system_python
py -3.13 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.13"
  goto :eof
)
py -3.12 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.12"
  goto :eof
)
python -c "import struct,sys; sys.exit(0 if (sys.version_info[:2] in ((3,12),(3,13)) and struct.calcsize('P')==8) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=python"
goto :eof
