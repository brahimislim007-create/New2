@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo =================================================
echo GESTION PROJETS V7 - ANALYSE ET EXECUTION COMPLETE
echo =================================================

if not exist ".venv\Scripts\python.exe" (
  echo [1/6] Preparation de l'environnement...
  call setup_visual_studio.bat
  if errorlevel 1 goto error
)

call ".venv\Scripts\activate.bat"

echo [2/6] Installation / verification des dependances...
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo [3/6] Analyse syntaxique et integration...
python scripts\verify_code.py
if errorlevel 1 goto error

echo [4/6] Tests unitaires et resilience...
python -m unittest discover -s tests -v
if errorlevel 1 goto error

echo [5/6] Verification de la configuration...
python scripts\check_system.py
if errorlevel 1 (
  echo Configuration incomplete: consultez les messages ci-dessus.
)

echo [6/6] Demarrage du programme...
python main.py
exit /b 0

:error
echo.
echo ================================================
echo ANALYSE TERMINEE AVEC ERREUR
echo Corrigez le probleme affiche puis relancez.
echo ================================================
pause
exit /b 1
