MISES A JOUR
============
Le dossier updates est réservé aux futures mises à jour.
Principe recommandé :
1. Sauvegarde automatique de la base PostgreSQL.
2. Téléchargement de la nouvelle version depuis un serveur sécurisé.
3. Vérification de version et d'intégrité.
4. Installation.
5. Migration de base de données.
6. Redémarrage.

Pour une vraie mise à jour automatique, il faut définir le serveur de mise à jour
et le mécanisme de distribution (installateur Windows, signature, URL sécurisée).
