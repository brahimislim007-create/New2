# Gestion Projets V8 Engineering Studio — notes de version

## Continuité V7
- Conservation des tables V7 (`projects`, `headquarters`, `users`, `audit_logs`).
- Les nouveaux modèles sont ajoutés séparément ; aucune donnée V7 n'est réinitialisée.
- Le premier démarrage crée les nouvelles tables via `Base.metadata.create_all`.

## Fonctions ajoutées
- Champs personnalisés persistants par projet.
- Planning par tâches avec dates, progression, priorité et responsable.
- Budgets, contrats de marchés, factures, dépenses, engagements et ressources.
- Centre de pièces jointes avec calcul SHA-256.
- Extraction textuelle PDF/DOCX/XLSX/CSV/TXT et statistiques descriptives des colonnes numériques Excel.
- Tableau de bord et exports PDF/XLSX/DOCX.

## Périmètre restant
Le diagramme Gantt interactif, le moteur de calculs de génie civil, la visualisation 3D IFC/BIM et l'analyse IA des médias ne sont pas livrés dans cette étape V8. Les fichiers IFC et médias peuvent être attachés au projet ; les fichiers IFC ne sont pas rendus en 3D.

## Vérification effectuée dans l'environnement de génération
- `python -m compileall -q main.py app tests scripts` : réussi.
- `python scripts/verify_code.py` : 26 fichiers Python vérifiés.
- L'application n'a pas pu être exécutée avec PySide6/PostgreSQL dans cet environnement : une validation fonctionnelle sur un poste Windows connecté à une base de test reste nécessaire.
