# Installation Gestion Projets V7 Pro

## 1. PostgreSQL
Créer la base et un utilisateur PostgreSQL.

## 2. Configuration
Copier `.env.example` vers `.env` et définir `DATABASE_URL`.

## 3. Installation
Double-cliquer sur :

`Install logiciel/INSTALLER.bat`

## 4. Réseau
Pour plusieurs ordinateurs, installer PostgreSQL sur un serveur accessible via le réseau
et utiliser la même base avec des comptes et permissions adaptés.
