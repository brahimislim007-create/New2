# Fiabilité et performance — Gestion Projets V7 Studio

## 1. Traitement asynchrone
Les opérations de chargement sont exécutées hors du thread de l'interface grâce
à une file de tâches et un worker dédié. L'objectif est de garder PySide6 réactif
pendant les accès PostgreSQL.

## 2. Queue
`AsyncTaskQueue` centralise les tâches lentes et fournit un `Future` pour suivre
leur résultat.

## 3. Cache
Un cache TTL de 30 secondes est utilisé pour les listes de projets et de sièges.
Il est invalidé après création ou modification des données.

## 4. Monitoring
Le programme surveille CPU, mémoire globale, mémoire du processus et taille de
la queue. Les données sont affichées dans la barre d'état toutes les 3 secondes.

## 5. Retry
Les opérations de base de données disposent d'une politique de 3 tentatives avec
backoff exponentiel pour les erreurs temporaires.

## 6. Logging
Les événements et erreurs sont enregistrés dans :

`logs/gestion_projets.log`

Les fichiers tournants sont limités à 5 Mo avec 5 sauvegardes.

## Limite importante
Ces mécanismes améliorent la robustesse mais ne remplacent pas :
- un serveur PostgreSQL correctement dimensionné ;
- des index SQL ;
- des sauvegardes ;
- des limites de connexion ;
- une authentification et une sécurité réseau appropriées.
