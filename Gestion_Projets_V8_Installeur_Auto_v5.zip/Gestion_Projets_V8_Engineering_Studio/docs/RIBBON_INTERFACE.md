# Interface Ribbon V7

Ajout d'une interface Ribbon structurée avec les onglets :

- ACCUEIL
- PROJETS
- INFRASTRUCTURES
- RAPPORTS
- ADMINISTRATION
- AIDE

Chaque onglet contient des groupes d'actions. Le Ribbon est construit avec
PySide6 et peut évoluer avec de nouvelles icônes, commandes, pages et outils.

Cette structure s'inspire des logiciels professionnels à commandes organisées,
sans prétendre reproduire ou copier l'interface d'un produit tiers.
