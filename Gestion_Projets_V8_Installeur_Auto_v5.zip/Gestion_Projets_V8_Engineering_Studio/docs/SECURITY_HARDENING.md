# Sécurité V7

## Ajouts
- Authentification locale avec PBKDF2-HMAC-SHA256 et 600 000 itérations.
- Rôles: ADMIN, MANAGER, USER.
- Permissions centralisées.
- Verrouillage temporaire après plusieurs échecs de connexion.
- Audit des connexions et créations d'utilisateurs.
- Sauvegarde PostgreSQL via pg_dump pour les utilisateurs autorisés.

## Avant production
1. Remplacer `INITIAL_ADMIN_PASSWORD`.
2. Utiliser PostgreSQL avec TLS/SSL si la base est accessible via Internet.
3. Restreindre le réseau (VPN/MPLS/firewall) et ne pas exposer PostgreSQL publiquement.
4. Mettre en place des sauvegardes automatiques et tester la restauration.
5. Utiliser un gestionnaire de secrets pour les mots de passe de production.
6. Ajouter MFA/SSO si l'organisation l'exige.
