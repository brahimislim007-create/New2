# Test de charge et de résistance

## Ce qui est testé automatiquement

### Queue / Async Worker
Le test envoie une rafale de **300 tâches** dans la file d'attente et vérifie que :
- toutes les tâches sont exécutées ;
- aucun résultat ne manque ;
- le worker répond dans le délai fixé.

### Retry
Une opération simulée échoue deux fois puis réussit à la troisième tentative.

### Monitoring
Le système vérifie que les métriques CPU/RAM/Queue peuvent être lues.

## Lancer sous Windows

Après l'installation de l'environnement :

`tests de charge` → `scripts\run_stress_test.bat`

Ou dans le terminal Visual Studio :

`python -m unittest tests.test_stress -v`

## Test PostgreSQL multi-utilisateur réel

Le test fourni ne doit pas envoyer de charge sur une base de production sans
autorisation. Pour tester PostgreSQL avec plusieurs utilisateurs, utilisez une
base de test séparée et créez un environnement de préproduction.

Recommandation initiale :
- 10 utilisateurs simultanés ;
- puis 25 ;
- puis 50 ;
- surveiller CPU, RAM, connexions PostgreSQL et temps de réponse ;
- arrêter le test si les erreurs ou la saturation deviennent importantes.
