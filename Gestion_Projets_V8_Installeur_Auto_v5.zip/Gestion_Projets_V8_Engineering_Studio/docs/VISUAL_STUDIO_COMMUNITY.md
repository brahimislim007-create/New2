# Configuration Visual Studio Community

## 1. Installer Visual Studio Community

Lors de l'installation, utiliser le fichier `.vsconfig` fourni ou sélectionner :

- Python development
- Desktop development with C++ (optionnel, utile pour les futurs modules C++)

## 2. Préparer le projet

Double-cliquez sur :

`setup_visual_studio.bat`

Ce script :

1. vérifie Python ;
2. crée `.venv` ;
3. installe les dépendances ;
4. crée `.env` si nécessaire.

## 3. Ouvrir le projet

Dans Visual Studio Community :

**File → Open → Folder**

Sélectionnez le dossier :

`Gestion_Projets_V7_Studio`

Choisissez l'interpréteur :

`.venv\Scripts\python.exe`

Puis utilisez `main.py` comme point de démarrage.

## 4. Débogage

Le projet peut être lancé avec :

- Visual Studio : Start / F5
- ou `RUN_DEBUG.bat`

Le vérificateur `scripts/verify_code.py` contrôle les liens essentiels du code avant le démarrage.

## PostgreSQL

Avant le premier démarrage réel, configurez `DATABASE_URL` dans `.env`.
