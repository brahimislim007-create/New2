# Politique de qualité du code

## Principes
- Une responsabilité claire par module.
- Interface graphique dans `app/ui`.
- Logique métier dans `app/services`.
- Modèles de données dans `app/models`.
- Configuration centralisée.
- Pas de mots de passe ou secrets dans le code.

## Contrôles réguliers
Le fichier `QUALITE_ET_TESTS.bat` exécute :
1. vérification de syntaxe ;
2. tests automatiques ;
3. analyse statique Ruff ;
4. contrôle du format Black.

## Avant chaque nouvelle version
- lancer tous les tests ;
- corriger les erreurs ;
- relancer les tests ;
- vérifier les fonctionnalités principales sur une base de test ;
- sauvegarder les résultats dans la documentation de la version.

## Important
Les corrections automatiques sont limitées au formatage et aux corrections
statiques sûres. Une erreur fonctionnelle doit être analysée et testée avant
d'être corrigée : le programme ne doit pas modifier son propre code pendant
l'exécution en production.
