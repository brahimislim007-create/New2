# Vérification de l'intégration

Le projet contient désormais :

- Navigation latérale ↔ pages centrales
- Ribbon ↔ commandes principales
- Dashboard ↔ `dashboard_metrics()`
- Projets ↔ PostgreSQL / SQLAlchemy
- Sièges ↔ PostgreSQL / SQLAlchemy
- Vue Gantt ↔ liste des projets
- Rapports ↔ PDF / Excel / Word
- Journal d'activité ↔ opérations utilisateur
- INSTALLER ↔ vérification système + vérification code + dépendances + démarrage

## Vérification automatique

Avant le lancement, `INSTALLER.bat` exécute :

1. `scripts/check_system.py`
2. `scripts/verify_code.py`
3. installation des dépendances
4. `main.py`

La vérification syntaxique ne remplace pas un test complet avec PostgreSQL réel,
mais elle détecte les erreurs de syntaxe et plusieurs liens essentiels manquants.
