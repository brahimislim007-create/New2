@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo PREPARATION ENVIRONNEMENT VISUAL STUDIO
echo ==========================================

where python >nul 2>nul
if errorlevel 1 (
  echo [ERREUR] Python n'est pas installe ou absent du PATH.
  pause
  exit /b 1
)

echo [1/4] Creation de l'environnement virtuel...
if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
)
if errorlevel 1 goto error

echo [2/4] Activation...
call .venv\Scripts\activate.bat

echo [3/4] Installation des dependances...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo [4/4] Configuration...
if not exist ".env" (
  copy /Y ".env.example" ".env" >nul
  echo.
  echo IMPORTANT: Configurez DATABASE_URL dans le fichier .env.
)

echo.
echo ENVIRONNEMENT PRET.
echo Dans Visual Studio Community:
echo - Ouvrez le dossier du projet
echo - Selectionnez l'interpreteur .venv\Scripts\python.exe
echo - Definissez main.py comme fichier de demarrage
pause
exit /b 0

:error
echo.
echo Une erreur est survenue pendant la preparation.
pause
exit /b 1
