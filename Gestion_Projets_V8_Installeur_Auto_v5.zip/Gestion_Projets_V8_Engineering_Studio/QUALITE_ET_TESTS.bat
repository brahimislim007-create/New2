@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==========================================
echo GESTION PROJETS V7 - QUALITE ET TESTS
echo ==========================================

if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv
    if errorlevel 1 goto error
)

call ".venv\Scripts\activate.bat"

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -r requirements-dev.txt
if errorlevel 1 goto error

echo.
echo [1/5] Verification syntaxique...
python scripts\verify_code.py
if errorlevel 1 goto error

echo.
echo [2/5] Tests unitaires et integration...
set "DATABASE_URL=sqlite+pysqlite:///:memory:"
python -m pytest tests
set "DATABASE_URL="
if errorlevel 1 goto error

echo.
echo [3/5] Analyse statique Ruff...
python -m ruff check app tests scripts
if errorlevel 1 goto error

echo.
echo [4/5] Verification formatage Black...
python -m black --check app tests scripts
if errorlevel 1 goto error

echo.
echo [5/5] Rapport termine avec succes.
echo ==========================================
echo QUALITE: OK
echo ==========================================
pause
exit /b 0

:error
echo.
echo ==========================================
echo QUALITE: ECHEC
echo Corrigez les erreurs affichees puis relancez.
echo ==========================================
pause
exit /b 1
