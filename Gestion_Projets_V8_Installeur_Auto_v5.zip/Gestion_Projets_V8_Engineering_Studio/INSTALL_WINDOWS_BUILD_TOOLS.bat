@echo off
cd /d "%~dp0installer"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_BUILD_TOOLS.ps1"
pause
