GESTION PROJETS V8 ENGINEERING STUDIO
====================================

V8 PART DE LA BASE V7 ET AJOUTE DES MODULES METIER. Les tables V8 sont
ajoutees sans supprimer les tables historiques V7. Faites une sauvegarde
PostgreSQL avant toute mise a jour de votre base de production.

NOUVEAUTES V8
-------------
1. Portefeuille de projets : creation, modification, suppression, recherche,
   dates, avancement et rattachement a un siege.
2. Champs personnalises : les noms ET valeurs sont persistants en base.
3. Planning : taches, dates, pourcentage, priorite et responsable.
4. Suivi financier : budgets, marches/contrats, factures, depenses,
   engagements et ressources (personnel, equipement, materiaux).
5. Documents : pieces jointes au projet, empreinte SHA-256, ouverture,
   extraction de texte PDF/DOCX/XLSX/CSV/TXT et analyse de colonnes numeriques Excel.
6. Rapports PDF, Excel et Word.
7. Sauvegarde PostgreSQL et journalisation deja presentes dans V7.

LIMITES A CONNAITRE
-------------------
- La creation automatique des nouvelles tables est additive (SQLAlchemy
  create_all). Elle ne modifie pas les colonnes existantes.
- L'IFC peut etre conserve comme piece jointe et son en-tete resume, mais
  le visualiseur BIM/IFC 3D n'est pas inclus dans cette livraison.
- Les images/audio/video sont stockes comme pieces jointes; aucun traitement
  IA de leur contenu n'est inclus.
- La planification est une liste de taches datees; un diagramme Gantt interactif
  complet n'est pas inclus dans cette livraison.
- Les calculs d'ingenierie ne remplacent jamais la validation par un ingenieur.
- L'application n'a pas ete executee sur votre serveur PostgreSQL/Windows ici.

INSTALLATION WINDOWS
--------------------
1. Decompressez le ZIP dans un dossier ou vous avez les droits d'ecriture.
2. Installez Python 3.12 ou 3.13 (64 bits) et PostgreSQL.
3. Double-cliquez INSTALLER_V8.bat.
4. Configurez le fichier .env : DATABASE_URL et mot de passe administrateur.
5. Définissez INITIAL_ADMIN_PASSWORD avec un mot de passe fort (au moins 10 caractères).
6. Lancez LANCER_GESTION_PROJETS_V8.bat.

MISE A JOUR DEPUIS V7
---------------------
1. Arretez les postes V7 et faites une sauvegarde avec pg_dump.
2. Conservez votre ancien dossier V7 sans le renommer ni l'ecraser.
3. Decompressez V8 dans un nouveau dossier.
4. Copiez votre ancien .env dans le dossier V8, puis verifiez DATABASE_URL.
5. Lancez V8 : les nouvelles tables sont creees au premier demarrage.
6. Verifiez les projets, les utilisateurs et les rapports avant de reprendre le travail.

ATTENTION : V8 utilise la meme base PostgreSQL configuree dans DATABASE_URL.
Ne lancez pas la premiere migration sur une base de production sans sauvegarde
et sans validation prealable de l'administrateur de base de donnees.

DEPENDANCES
-----------
Installees par INSTALLER_V8.bat depuis requirements.txt : PySide6, SQLAlchemy,
psycopg, reportlab, openpyxl, python-docx, pypdf, psutil et outils associes.

SUPPORT ET DIAGNOSTIC
---------------------
- Verifier le code : python scripts\verify_code.py
- Verifier le systeme : python scripts\check_system.py
- Journal : logs\gestion_projets.log
- Sauvegardes : backups\
