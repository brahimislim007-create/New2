@echo off
cd /d "%~dp0\.."
echo ==========================================
echo GESTION PROJETS V7 - STRESS / LOAD TEST
echo ==========================================

if not exist ".venv\Scripts\python.exe" (
  echo Environnement .venv absent.
  echo Executez setup_visual_studio.bat.
  pause
  exit /b 1
)

call .venv\Scripts\activate.bat
python -m unittest tests.test_stress -v
pause
