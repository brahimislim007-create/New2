@echo off
cd /d "%~dp0\.."
call LANCER_GESTION_PROJETS_V8.bat
