from pathlib import Path
import sys

required = [
    "main.py",
    "requirements.txt",
    ".env.example",
    "app/database.py",
    "app/models/models.py",
    "app/services/project_service.py",
    "app/ui/main_window.py",
    "app/reports/report_service.py",
]

missing = [f for f in required if not Path(f).exists()]
for folder in ["reports", "logs", "backups"]:
    Path(folder).mkdir(exist_ok=True)

print("SYSTEM CHECK")
if missing:
    for item in missing:
        print("MISSING:", item)
    sys.exit(1)

print("OK")
sys.exit(0)
