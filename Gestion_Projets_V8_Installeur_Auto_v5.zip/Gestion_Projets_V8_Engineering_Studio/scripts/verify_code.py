import ast
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
files = list(ROOT.rglob("*.py"))
errors = []

for path in files:
    try:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as e:
        errors.append(f"{path.relative_to(ROOT)}: {e}")

required_files = [
    "main.py",
    "app/config.py",
    "app/database.py",
    "app/resilience.py",
    "app/services/security_service.py",
    "app/ui/login_dialog.py",
    "app/ui/ribbon.py",
    "app/services/backup_service.py",
    "app/services/project_service.py",
    "app/services/v8_service.py",
    "app/services/document_service.py",
    "app/ui/main_window.py",
]
for rel in required_files:
    if not (ROOT / rel).exists():
        errors.append(f"Fichier manquant: {rel}")

required = {
    "main.py": ["import app.models", "Base.metadata.create_all"],
    "app/services/project_service.py": ["create_project", "dashboard_metrics", "retry", "cache_clear"],
    "app/resilience.py": ["AsyncTaskQueue", "retry", "system_metrics", "RotatingFileHandler"],
    "app/ui/main_window.py": ["RibbonBar", "system_metrics", "run_backup", "show_page", "add_record_dialog"],
    "app/services/v8_service.py": ["save_custom_field", "finance_summary", "add_record", "delete_record"],
    "app/services/document_service.py": ["attach_file", "extract_text", "analyze_spreadsheet"],
}

for rel, names in required.items():
    content = (ROOT / rel).read_text(encoding="utf-8")
    for name in names:
        if name not in content:
            errors.append(f"{rel}: integration manquante -> {name}")

if errors:
    print("CODE CHECK FAILED")
    print("\n".join(errors))
    sys.exit(1)

print("CODE CHECK OK")
print(f"{len(files)} fichiers Python vérifiés.")
