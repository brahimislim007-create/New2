@echo off
cd /d "%~dp0\.."
python scripts\verify_code.py
if errorlevel 1 pause
python -m unittest discover -s tests -v
pause
