@echo off
cd /d "%~dp0\.."
if not exist backups mkdir backups
echo Backup PostgreSQL...
pg_dump -Fc -f "backups\gestion_projets_v7.backup" gestion_projets_v7
if errorlevel 1 (
 echo Backup failed. Verify PostgreSQL tools and credentials.
 pause
 exit /b 1
)
echo Backup completed.
pause
