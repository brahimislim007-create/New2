@echo off
cd /d "%~dp0installer"
call BUILD_ALL_WINDOWS.bat
