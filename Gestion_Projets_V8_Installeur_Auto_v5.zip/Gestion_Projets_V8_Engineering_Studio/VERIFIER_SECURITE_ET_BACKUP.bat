@echo off
cd /d "%~dp0"
echo === Verification securite / sauvegarde ===
if not exist ".venv\Scripts\python.exe" (
 echo Executez d'abord setup_visual_studio.bat
 pause
 exit /b 1
)
call ".venv\Scripts\activate.bat"
python scripts\verify_code.py
where pg_dump
if errorlevel 1 echo ATTENTION: pg_dump introuvable. Installez PostgreSQL client tools pour les sauvegardes.
pause
