@echo off
setlocal
cd /d "%~dp0"
call ".venv\Scripts\activate.bat"
if errorlevel 1 (
 echo Executez d'abord QUALITE_ET_TESTS.bat
 pause
 exit /b 1
)
python -m ruff check app tests scripts --fix
python -m black app tests scripts
echo Correction de style terminee. Relancez QUALITE_ET_TESTS.bat.
pause
