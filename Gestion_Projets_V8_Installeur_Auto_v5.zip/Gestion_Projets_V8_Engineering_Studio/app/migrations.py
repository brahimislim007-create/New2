"""Migration additive au démarrage.

SQLAlchemy ``create_all`` crée les tables absentes mais n'ajoute pas les colonnes
manquantes aux tables existantes (cas d'une base V7). Ce module ajoute donc les
colonnes V8 manquantes, sans jamais supprimer ni modifier de colonne ou de donnée.

Les colonnes ajoutées sont NULL-ables : une contrainte NOT NULL ne peut pas être
appliquée à une table qui contient déjà des lignes sans valeur par défaut.
"""
from __future__ import annotations

from sqlalchemy import inspect, text

from app.resilience import logger


def ensure_additive_columns(engine, base) -> list[str]:
    inspector = inspect(engine)
    dialect = engine.dialect
    preparer = dialect.identifier_preparer
    added: list[str] = []
    with engine.begin() as conn:
        for table in base.metadata.sorted_tables:
            if not inspector.has_table(table.name):
                continue  # la table sera créée par create_all
            existing = {col["name"] for col in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in existing:
                    continue
                col_type = column.type.compile(dialect=dialect)
                conn.execute(text(
                    f"ALTER TABLE {preparer.quote(table.name)} "
                    f"ADD COLUMN {preparer.quote(column.name)} {col_type}"
                ))
                added.append(f"{table.name}.{column.name}")
                logger.warning("Migration additive : colonne ajoutée %s.%s", table.name, column.name)
    return added
