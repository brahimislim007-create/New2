import os
import struct
import sys
from pathlib import Path


def application_directory() -> Path:
    """Dossier où vivent .env, logs, rapports, sauvegardes et pièces jointes."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def resource_directory() -> Path:
    """Dossier des ressources embarquées (QSS, etc.), y compris dans l'EXE PyInstaller."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", application_directory()))
    return Path(__file__).resolve().parents[1]


def is_64bit_python() -> bool:
    return struct.calcsize("P") == 8


def read_text_auto(path: Path) -> str:
    """Lit un fichier texte écrit par Notepad Windows (UTF-8 avec ou sans BOM, ou ANSI/cp1252)."""
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def load_env():
    candidates = [
        application_directory() / ".env",
        Path.cwd() / ".env",
    ]

    for env in candidates:
        if not env.exists():
            continue
        for line in read_text_auto(env).splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip())
        return env
    return None

load_env()
