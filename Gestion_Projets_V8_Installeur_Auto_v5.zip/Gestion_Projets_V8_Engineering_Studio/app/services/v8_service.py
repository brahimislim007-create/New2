"""Services métier V8 : planning, finances, champs personnalisés, documents.

Le schéma V7 est conservé ; les tables V8 sont ajoutées de façon additive.
"""
from __future__ import annotations
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy.exc import IntegrityError

from app.database import SessionLocal
from app.models import (
    Project, ProjectCustomField, ProjectTask, ProjectBudget, ProcurementContract,
    ProjectInvoice, ProjectExpense, ProjectCommitment, ProjectResource,
)
from app.resilience import logger, cache_clear
from app.services.project_service import derive_status, PROJECT_STATUSES

CURRENCIES = ("TND", "EUR", "USD")

ENTITY_MAP = {
    "tasks": ProjectTask,
    "budgets": ProjectBudget,
    "contracts": ProcurementContract,
    "invoices": ProjectInvoice,
    "expenses": ProjectExpense,
    "commitments": ProjectCommitment,
    "resources": ProjectResource,
}

DATE_FIELDS = {
    "start_date", "end_date", "signed_date", "revision_date", "invoice_date",
    "due_date", "expense_date", "commitment_date",
}
DECIMAL_FIELDS = {"amount", "quantity"}
ALLOWED_FIELDS = {
    "tasks": {"title", "description", "start_date", "end_date", "progress", "status", "priority", "assignee"},
    "budgets": {"label", "amount", "currency", "revision_date", "notes"},
    "contracts": {"reference", "title", "supplier", "amount", "currency", "status", "signed_date", "start_date", "end_date", "notes"},
    "invoices": {"reference", "invoice_type", "party", "amount", "currency", "invoice_date", "due_date", "status", "notes"},
    "expenses": {"category", "description", "amount", "currency", "expense_date", "supplier", "invoice_reference"},
    "commitments": {"reference", "description", "amount", "currency", "commitment_date", "status"},
    "resources": {"name", "resource_type", "quantity", "unit", "start_date", "end_date", "notes"},
}
REQUIRED_FIELDS = {
    "tasks": ["title"],
    "budgets": ["label", "amount"],
    "contracts": ["reference", "title", "amount"],
    "invoices": ["reference", "amount"],
    "expenses": ["category", "description", "amount"],
    "commitments": ["reference", "description", "amount"],
    "resources": ["name"],
}


def _parse_date(key: str, value: Any) -> date:
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(f"Date invalide pour {key} (format attendu AAAA-MM-JJ).") from exc


def _normalise_payload(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    if kind not in ENTITY_MAP:
        raise ValueError("Type de donnée V8 non reconnu.")
    cleaned: dict[str, Any] = {}
    for key, value in payload.items():
        if key not in ALLOWED_FIELDS[kind]:
            continue
        if isinstance(value, str):
            value = value.strip() or None
        if key in DATE_FIELDS and value:
            value = _parse_date(key, value)
        if key in DECIMAL_FIELDS:
            if value is None or value == "":
                # Valeur absente : on laisse le modèle appliquer son défaut ; le contrôle
                # des champs obligatoires refuse un montant absent.
                continue
            try:
                value = Decimal(str(value))
            except InvalidOperation as exc:
                raise ValueError(f"Valeur numérique invalide pour {key}.") from exc
            if not value.is_finite():
                raise ValueError(f"Valeur numérique invalide pour {key}.")
            if value < 0:
                raise ValueError("Les montants et quantités ne peuvent pas être négatifs.")
        if key == "progress":
            try:
                value = max(0, min(100, int(value or 0)))
            except (TypeError, ValueError) as exc:
                raise ValueError("L'avancement doit être un nombre entre 0 et 100.") from exc
        if key == "currency" and value is not None:
            value = str(value).upper()
            if value not in CURRENCIES:
                raise ValueError(f"Devise non prise en charge : {value}.")
        cleaned[key] = value
    return cleaned


def _check_date_order(start: date | None, end: date | None) -> None:
    if start and end and end < start:
        raise ValueError("La date de fin doit être postérieure ou égale à la date de début.")


def add_record(kind: str, project_id: int, **payload):
    model = ENTITY_MAP.get(kind)
    if model is None:
        raise ValueError("Type de donnée V8 non reconnu.")
    data = _normalise_payload(kind, payload)
    # Un montant de 0 est valide ; seule l'absence de valeur est refusée.
    if any(data.get(field) in (None, "") for field in REQUIRED_FIELDS[kind]):
        raise ValueError("Veuillez renseigner les champs obligatoires.")
    if "start_date" in data and "end_date" in data:
        _check_date_order(data.get("start_date"), data.get("end_date"))
    db = SessionLocal()
    try:
        if not db.get(Project, int(project_id)):
            raise ValueError("Le projet sélectionné n'existe pas.")
        item = model(project_id=int(project_id), **data)
        db.add(item)
        db.commit()
        db.refresh(item)
        logger.info("V8: ajout %s #%s au projet %s", kind, item.id, project_id)
        return item
    except IntegrityError as exc:
        db.rollback()
        raise ValueError("Cette référence existe déjà ou une contrainte de données est violée.") from exc
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def list_records(kind: str, project_id: int | None = None):
    model = ENTITY_MAP.get(kind)
    if model is None:
        raise ValueError("Type de donnée V8 non reconnu.")
    db = SessionLocal()
    try:
        query = db.query(model)
        if project_id is not None:
            query = query.filter(model.project_id == int(project_id))
        return query.order_by(model.id.desc()).all()
    finally:
        db.close()


def delete_record(kind: str, record_id: int):
    model = ENTITY_MAP.get(kind)
    if model is None:
        raise ValueError("Type de donnée V8 non reconnu.")
    db = SessionLocal()
    try:
        item = db.get(model, int(record_id))
        if item is None:
            return False
        db.delete(item)
        db.commit()
        logger.info("V8: suppression %s #%s", kind, record_id)
        return True
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def save_custom_field(project_id: int, field_name: str, field_value: str):
    name = (field_name or "").strip()
    if not name:
        raise ValueError("Le nom du champ personnalisé est obligatoire.")
    if len(name) > 120:
        raise ValueError("Le nom du champ ne doit pas dépasser 120 caractères.")
    db = SessionLocal()
    try:
        if not db.get(Project, int(project_id)):
            raise ValueError("Projet introuvable.")
        item = db.query(ProjectCustomField).filter_by(project_id=int(project_id), field_name=name).first()
        if item is None:
            item = ProjectCustomField(project_id=int(project_id), field_name=name, field_value=field_value)
            db.add(item)
        else:
            item.field_value = field_value
        db.commit()
        db.refresh(item)
        return item
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def list_custom_fields(project_id: int):
    db = SessionLocal()
    try:
        return db.query(ProjectCustomField).filter_by(project_id=int(project_id)).order_by(ProjectCustomField.field_name).all()
    finally:
        db.close()


def update_project(project_id: int, **values):
    """Met à jour un projet. Les dates et le statut sont vérifiés par rapport
    aux valeurs finales (existantes + modifiées), pas seulement aux valeurs envoyées."""
    allowed = {"code", "name", "description", "progress", "status", "start_date", "end_date", "headquarters_id"}
    clean = {k: v for k, v in values.items() if k in allowed}
    for key in ("start_date", "end_date"):
        if key in clean and clean[key]:
            clean[key] = _parse_date(key, clean[key])
        elif key in clean:
            clean[key] = None
    if "progress" in clean:
        try:
            clean["progress"] = max(0, min(100, int(clean["progress"])))
        except (TypeError, ValueError) as exc:
            raise ValueError("L'avancement doit être un nombre entre 0 et 100.") from exc
    for key in ("code", "name"):
        if key in clean:
            clean[key] = (clean[key] or "").strip()
            if not clean[key]:
                raise ValueError("Le code et le nom du projet ne peuvent pas être vides.")
    if "status" in clean and clean["status"] not in PROJECT_STATUSES:
        raise ValueError("Statut de projet invalide.")

    db = SessionLocal()
    try:
        item = db.get(Project, int(project_id))
        if item is None:
            raise ValueError("Projet introuvable.")
        # Vérification sur les valeurs finales.
        final_start = clean["start_date"] if "start_date" in clean else item.start_date
        final_end = clean["end_date"] if "end_date" in clean else item.end_date
        _check_date_order(final_start, final_end)
        # Le statut suit l'avancement, sauf « Suspendu » choisi explicitement.
        if "progress" in clean or "status" in clean:
            progress = clean.get("progress", item.progress)
            requested = clean.get("status", item.status)
            clean["status"] = derive_status(progress, requested)
        for key, value in clean.items():
            setattr(item, key, value)
        db.commit()
        db.refresh(item)
        cache_clear()
        return item
    except IntegrityError as exc:
        db.rollback()
        raise ValueError("Le code du projet est déjà utilisé.") from exc
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def delete_project(project_id: int):
    db = SessionLocal()
    try:
        item = db.get(Project, int(project_id))
        if item is None:
            return False
        db.delete(item)
        db.commit()
        cache_clear()
        return True
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def finance_summary(project_id: int | None = None) -> dict[str, dict[str, float]]:
    """Totaux par catégorie et par devise. Les montants de devises différentes ne sont jamais additionnés."""
    db = SessionLocal()
    try:
        from sqlalchemy import func

        def by_currency(model):
            q = db.query(model.currency, func.coalesce(func.sum(model.amount), 0)).group_by(model.currency)
            if project_id is not None:
                q = q.filter(model.project_id == int(project_id))
            return {str(cur or "TND"): float(total or 0) for cur, total in q.all()}

        return {
            "budgets": by_currency(ProjectBudget),
            "contracts": by_currency(ProcurementContract),
            "invoices": by_currency(ProjectInvoice),
            "expenses": by_currency(ProjectExpense),
            "commitments": by_currency(ProjectCommitment),
        }
    finally:
        db.close()
