"""Project document vault: safe copy, SHA-256 integrity, and office/PDF text extraction."""
from __future__ import annotations
import hashlib
import re
import shutil
from pathlib import Path
from datetime import datetime

from app.database import SessionLocal
from app.models import Project, ProjectAttachment
from app.config import application_directory

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".xlsx", ".xlsm", ".csv", ".txt", ".ifc", ".jpg", ".jpeg", ".png", ".mp4", ".mp3", ".wav"}


def _storage_root() -> Path:
    root = application_directory() / "data" / "attachments"
    root.mkdir(parents=True, exist_ok=True)
    return root


def attach_file(project_id: int, source_path: str | Path):
    source = Path(source_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError("Le fichier sélectionné est introuvable.")
    ext = source.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Format non pris en charge : {ext or 'sans extension'}")
    hasher = hashlib.sha256()
    with source.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    digest = hasher.hexdigest()
    db = SessionLocal()
    try:
        # Vérifier le projet AVANT de copier le fichier : aucun fichier orphelin.
        if not db.get(Project, int(project_id)):
            raise ValueError("Projet introuvable.")
        dest_dir = _storage_root() / f"project_{int(project_id)}"
        dest_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", source.name).strip("._") or "document"
        target = dest_dir / f"{datetime.now():%Y%m%d_%H%M%S_%f}_{safe_name}"
        shutil.copy2(source, target)
        item = ProjectAttachment(
            project_id=int(project_id), original_name=source.name,
            stored_path=str(target.relative_to(application_directory())),
            extension=ext, file_size=target.stat().st_size, sha256=digest,
        )
        db.add(item); db.commit(); db.refresh(item)
        return item
    except Exception:
        db.rollback()
        target.unlink(missing_ok=True)
        raise
    finally:
        db.close()


def list_attachments(project_id: int):
    db = SessionLocal()
    try:
        return db.query(ProjectAttachment).filter_by(project_id=int(project_id)).order_by(ProjectAttachment.uploaded_at.desc()).all()
    finally:
        db.close()


def resolve_attachment(item: ProjectAttachment) -> Path:
    path = (application_directory() / item.stored_path).resolve()
    root = _storage_root().resolve()
    if root not in path.parents:
        raise ValueError("Chemin de pièce jointe non autorisé.")
    return path


def extract_text(file_path: str | Path, max_chars: int = 100_000) -> str:
    path = Path(file_path)
    ext = path.suffix.lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("Installez pypdf pour lire les PDF (pip install pypdf).") from exc
        reader = PdfReader(str(path))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages)[:max_chars]
    if ext == ".docx":
        from docx import Document
        doc = Document(str(path))
        chunks = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            chunks.extend(" | ".join(cell.text for cell in row.cells) for row in table.rows)
        return "\n".join(chunks)[:max_chars]
    if ext in {".xlsx", ".xlsm"}:
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        chunks = []
        for ws in wb.worksheets:
            chunks.append(f"[Feuille: {ws.title}]")
            for row in ws.iter_rows(values_only=True):
                vals = [str(v) for v in row if v is not None]
                if vals:
                    chunks.append(" | ".join(vals))
        wb.close()
        return "\n".join(chunks)[:max_chars]
    if ext == ".csv":
        return path.read_text(encoding="utf-8-sig", errors="replace")[:max_chars]
    if ext == ".txt":
        return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
    if ext == ".ifc":
        # IFC is preserved as an attachment; this is a lightweight header/entity summary, not a 3D viewer.
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = [
            line.strip() for line in text.splitlines()
            if line.strip() and (line.startswith("FILE_") or (line.startswith("#") and "=" in line))
        ]
        return "\n".join(lines[:200]) or "Fichier IFC enregistré. L'aperçu 3D IFC n'est pas activé dans cette version."
    return f"Fichier {ext} enregistré. L'extraction de contenu n'est pas disponible pour ce format."


def analyze_spreadsheet(file_path: str | Path) -> dict:
    import math
    from openpyxl import load_workbook
    wb = load_workbook(file_path, read_only=True, data_only=True)
    report = {"file": Path(file_path).name, "sheets": []}
    try:
        for ws in wb.worksheets:
            row_count = 0
            numeric: dict[str, dict] = {}
            headers: list[str] = []
            for idx, row in enumerate(ws.iter_rows(values_only=True)):
                row_count += 1
                if idx == 0:
                    headers = [str(v) if v is not None else f"Colonne {i+1}" for i, v in enumerate(row)]
                    continue
                for col, value in enumerate(row):
                    if isinstance(value, bool) or not isinstance(value, (int, float)):
                        continue
                    number = float(value)
                    if not math.isfinite(number):
                        continue
                    key = headers[col] if col < len(headers) else f"Colonne {col+1}"
                    item = numeric.setdefault(key, {"count": 0, "min": number, "max": number, "sum": 0.0})
                    item["count"] += 1
                    item["min"] = min(item["min"], number)
                    item["max"] = max(item["max"], number)
                    item["sum"] += number
            stats = {k: {**v, "average": v["sum"] / v["count"]} for k, v in numeric.items() if v["count"]}
            report["sheets"].append({"name": ws.title, "rows": row_count, "columns": len(headers), "numeric": stats})
    finally:
        wb.close()
    return report
