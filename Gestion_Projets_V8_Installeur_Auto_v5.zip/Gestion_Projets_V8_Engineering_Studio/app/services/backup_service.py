import os, subprocess
from datetime import datetime
from urllib.parse import urlparse, unquote
from app.config import application_directory
from app.resilience import logger

def backup_database():
    url = os.getenv("DATABASE_URL", "")
    if not url.startswith("postgresql"):
        raise RuntimeError("La sauvegarde automatique est configurée pour PostgreSQL.")
    parsed = urlparse(url)
    backup_dir = application_directory() / "backups"; backup_dir.mkdir(parents=True, exist_ok=True)
    filename = backup_dir / f"gestion_v8_{datetime.now():%Y%m%d_%H%M%S}.sql"
    env = os.environ.copy()
    if parsed.password: env["PGPASSWORD"] = unquote(parsed.password)
    host = parsed.hostname or "localhost"
    port = str(parsed.port or 5432)
    user = unquote(parsed.username or "")
    database = parsed.path.lstrip("/")
    pg_dump = os.getenv("PG_DUMP_PATH") or "pg_dump"  # ex. C:\Program Files\PostgreSQL\16\bin\pg_dump.exe
    cmd = [pg_dump, "-h", host, "-p", port, "-U", user, "-F", "p", "-f", str(filename), database]
    result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "pg_dump a échoué.")
    logger.info("Sauvegarde créée: %s", filename)
    return filename
