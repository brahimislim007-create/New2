import base64
import hashlib
import hmac
import os
from datetime import datetime, timedelta
from sqlalchemy.exc import OperationalError

from app.database import SessionLocal
from app.models import User, AuditLog
from app.resilience import logger, retry

ROLES = {"ADMIN", "MANAGER", "USER"}
PERMISSIONS = {
    "ADMIN": {"projects.read","projects.write","headquarters.read","headquarters.write",
              "reports.export","users.manage","backup.run"},
    "MANAGER": {"projects.read","projects.write","headquarters.read","headquarters.write",
                "reports.export","backup.run"},
    "USER": {"projects.read","headquarters.read","reports.export"},
}
MAX_ATTEMPTS = 5
WINDOW_SECONDS = 300
LOCK_SECONDS = 300
PBKDF2_ROUNDS = 600_000
MIN_PASSWORD_LENGTH = 10


def hash_password(password: str) -> str:
    if not password or len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Le mot de passe doit contenir au moins {MIN_PASSWORD_LENGTH} caractères.")
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return "pbkdf2_sha256$%d$%s$%s" % (
        PBKDF2_ROUNDS,
        base64.b64encode(salt).decode(),
        base64.b64encode(digest).decode()
    )


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, rounds, salt_b64, hash_b64 = stored.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
        return hmac.compare_digest(digest, expected)
    except Exception:
        return False


def has_permission(user, permission):
    return bool(user and permission in PERMISSIONS.get(user.role, set()))


def audit(db, username, action, details=None):
    db.add(AuditLog(username=username, action=action, details=details))


def _is_locked(db, username: str) -> bool:
    """Verrouillage persistant : compte les échecs récents dans le journal d'audit.
    Ainsi le blocage survit au redémarrage et est partagé par tous les postes."""
    since = datetime.utcnow() - timedelta(seconds=max(WINDOW_SECONDS, LOCK_SECONDS))
    failures = (
        db.query(AuditLog)
        .filter(AuditLog.username == username, AuditLog.action == "LOGIN_FAILED", AuditLog.created_at >= since)
        .order_by(AuditLog.created_at.desc())
        .limit(MAX_ATTEMPTS)
        .all()
    )
    if len(failures) < MAX_ATTEMPTS:
        return False
    # Le blocage dure LOCK_SECONDS après le dernier des MAX_ATTEMPTS échecs.
    last_block_start = failures[MAX_ATTEMPTS - 1].created_at
    return datetime.utcnow() < last_block_start + timedelta(seconds=LOCK_SECONDS)


@retry(attempts=3, exceptions=(OperationalError, ConnectionError, TimeoutError))
def create_user(username, password, role="USER"):
    username = (username or "").strip()
    role = (role or "USER").upper()
    if not username:
        raise ValueError("Nom d'utilisateur obligatoire.")
    if role not in ROLES:
        raise ValueError("Rôle invalide.")
    db = SessionLocal()
    try:
        if db.query(User).filter_by(username=username).first():
            raise ValueError("Ce nom d'utilisateur existe déjà.")
        user = User(username=username, password_hash=hash_password(password), role=role)
        db.add(user)
        db.flush()
        audit(db, username, "USER_CREATED", f"role={role}")
        db.commit()
        db.refresh(user)
        return user
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def list_users():
    db = SessionLocal()
    try:
        items = db.query(User).order_by(User.username).all()
        for item in items:
            db.expunge(item)
        return items
    finally:
        db.close()


def authenticate(username, password):
    username = (username or "").strip()
    db = SessionLocal()
    try:
        if not username or not password:
            return None
        if _is_locked(db, username):
            audit(db, username, "LOGIN_BLOCKED", None)
            db.commit()
            return None
        user = db.query(User).filter_by(username=username).first()
        if not user or not user.is_active or not verify_password(password, user.password_hash):
            audit(db, username, "LOGIN_FAILED", None)
            db.commit()
            return None
        audit(db, username, "LOGIN_SUCCESS", f"role={user.role}")
        db.commit()
        db.refresh(user)  # le commit expire les attributs ; on les recharge avant de détacher
        db.expunge(user)
        return user
    finally:
        db.close()


def ensure_initial_admin():
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            username = os.getenv("INITIAL_ADMIN_USERNAME", "admin").strip() or "admin"
            password = os.getenv("INITIAL_ADMIN_PASSWORD", "")
            if not password:
                logger.warning("Aucun administrateur initial créé: INITIAL_ADMIN_PASSWORD absent.")
                return False
            user = User(username=username, password_hash=hash_password(password), role="ADMIN")
            db.add(user)
            audit(db, username, "INITIAL_ADMIN_CREATED", "Bootstrap")
            db.commit()
            logger.info("Administrateur initial créé.")
            return True
        return False
    finally:
        db.close()
