from datetime import date

from sqlalchemy.exc import OperationalError

from app.database import SessionLocal
from app.models import Project, Headquarters
from app.resilience import logger, retry, cache_get, cache_set, cache_clear

# Seules les erreurs de connexion/transitoires sont relancées ; les erreurs de saisie ne le sont pas.
TRANSIENT_DB_ERRORS = (OperationalError, ConnectionError, TimeoutError)

PROJECT_STATUSES = ("Nouveau", "En cours", "Suspendu", "Terminé")


def derive_status(progress: int, requested: str | None = None) -> str:
    """Statut déduit de l'avancement. « Suspendu » est conservé quand il est demandé explicitement."""
    if requested == "Suspendu":
        return "Suspendu"
    if progress >= 100:
        return "Terminé"
    if progress <= 0:
        return "Nouveau"
    return "En cours"


def _clean(value):
    return (value or "").strip()


def _parse_optional_date(label, value):
    if not value:
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(f"{label} invalide (format attendu AAAA-MM-JJ).") from exc

@retry(attempts=3, delay=0.5, backoff=2.0, exceptions=TRANSIENT_DB_ERRORS)
def create_project(code, name, progress=0, headquarters_id=None, description=None,
                   start_date=None, end_date=None, status=None):
    code = _clean(code)
    name = _clean(name)
    if not code:
        raise ValueError("Le code du projet est obligatoire.")
    if not name:
        raise ValueError("Le nom du projet est obligatoire.")

    try:
        progress = int(progress)
    except (TypeError, ValueError):
        raise ValueError("L'avancement doit être un nombre entre 0 et 100.")

    progress = max(0, min(100, progress))
    status = derive_status(progress, status)
    start, end = _parse_optional_date("Date de début", start_date), _parse_optional_date("Date de fin", end_date)
    if start and end and end < start:
        raise ValueError("La date de fin doit être postérieure ou égale à la date de début.")

    db = SessionLocal()
    try:
        item = Project(
            code=code, name=name, progress=progress, status=status,
            headquarters_id=headquarters_id,
            description=_clean(description) or None,
            start_date=start, end_date=end,
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        cache_clear()
        logger.info("Projet créé: %s (%s)", item.name, item.code)
        return item
    except Exception:
        db.rollback()
        logger.exception("Erreur création projet")
        raise
    finally:
        db.close()

@retry(attempts=3, exceptions=TRANSIENT_DB_ERRORS)
def list_projects():
    key = "projects"
    cached = cache_get(key)
    if cached is not None:
        logger.info("Cache HIT: projects")
        return cached

    db = SessionLocal()
    try:
        items = db.query(Project).order_by(Project.id.desc()).all()
        # Données détachées: éviter une session DB ouverte dans l'UI.
        for item in items:
            db.expunge(item)
        cache_set(key, items)
        logger.info("Cache MISS: projects (%s éléments)", len(items))
        return items
    finally:
        db.close()

@retry(attempts=3, exceptions=TRANSIENT_DB_ERRORS)
def create_headquarters(name, address=None, city=None):
    name = _clean(name)
    if not name:
        raise ValueError("Le nom du siège est obligatoire.")

    db = SessionLocal()
    try:
        item = Headquarters(
            name=name,
            address=_clean(address) or None,
            city=_clean(city) or None,
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        cache_clear()
        logger.info("Siège créé: %s", item.name)
        return item
    except Exception:
        db.rollback()
        logger.exception("Erreur création siège")
        raise
    finally:
        db.close()

@retry(attempts=3, exceptions=TRANSIENT_DB_ERRORS)
def list_headquarters():
    key = "headquarters"
    cached = cache_get(key)
    if cached is not None:
        return cached
    db = SessionLocal()
    try:
        items = db.query(Headquarters).order_by(Headquarters.name).all()
        for item in items:
            db.expunge(item)
        cache_set(key, items)
        return items
    finally:
        db.close()

def dashboard_metrics():
    items = list_projects()
    headquarters = list_headquarters()
    total = len(items)
    active = sum(1 for p in items if p.status == "En cours")
    completed = sum(1 for p in items if p.status == "Terminé")
    average_progress = round(sum(p.progress for p in items) / total, 1) if total else 0
    return {
        "total": total,
        "active": active,
        "completed": completed,
        "headquarters": len(headquarters),
        "average_progress": average_progress,
    }
