"""
Infrastructure de fiabilité pour Gestion Projets V8 Engineering Studio.
Async worker + Queue + Cache + Retry + Monitoring + Logging.
"""
import asyncio
import functools
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import queue
import sys
import threading
import time
from concurrent.futures import Future
from cachetools import TTLCache

from app.config import application_directory

LOG_DIR = application_directory() / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger = logging.getLogger("gestion_projets")
logger.setLevel(logging.INFO)
if not logger.handlers:
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(threadName)s | %(name)s | %(message)s"
    )
    file_handler = RotatingFileHandler(
        LOG_DIR / "gestion_projets.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # En mode fenêtré (PyInstaller --windowed), sys.stderr peut être None.
    if sys.stderr is not None:
        console = logging.StreamHandler(sys.stderr)
        console.setFormatter(formatter)
        logger.addHandler(console)

cache = TTLCache(maxsize=512, ttl=30)
_cache_lock = threading.Lock()

def retry(attempts=3, delay=0.5, backoff=2.0, exceptions=(ConnectionError, TimeoutError)):
    """Retry avec backoff exponentiel, uniquement pour les erreurs temporaires.

    Les erreurs de saisie (ValueError, etc.) ne sont jamais relancées.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            wait = delay
            last_error = None
            for attempt in range(1, attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    last_error = exc
                    logger.warning(
                        "Tentative %s/%s échouée pour %s: %s",
                        attempt, attempts, func.__name__, exc
                    )
                    if attempt < attempts:
                        time.sleep(wait)
                        wait *= backoff
            logger.exception("Echec définitif: %s", func.__name__)
            raise last_error
        return wrapper
    return decorator

class AsyncTaskQueue:
    """
    File d'attente non bloquante: les tâches sont exécutées par un thread
    dédié avec une boucle asyncio. L'interface PySide6 reste réactive.
    """
    def __init__(self):
        self._queue = queue.Queue()
        self._thread = threading.Thread(
            target=self._run, name="AsyncTaskWorker", daemon=True
        )
        self._started = False
        self._lock = threading.Lock()

    def start(self):
        with self._lock:
            if not self._started:
                self._started = True
                self._thread.start()
                logger.info("AsyncTaskQueue démarrée")

    def submit(self, func, *args, **kwargs):
        self.start()
        future = Future()
        self._queue.put((func, args, kwargs, future))
        logger.info("Tâche ajoutée à la queue: %s", getattr(func, "__name__", str(func)))
        return future

    def _run(self):
        while True:
            func, args, kwargs, future = self._queue.get()
            try:
                if future.set_running_or_notify_cancel():
                    result = func(*args, **kwargs)
                    if asyncio.iscoroutine(result):
                        result = asyncio.run(result)
                    future.set_result(result)
                    logger.info("Tâche terminée: %s", getattr(func, "__name__", str(func)))
            except Exception as exc:
                logger.exception("Erreur dans une tâche asynchrone")
                future.set_exception(exc)
            finally:
                self._queue.task_done()

task_queue = AsyncTaskQueue()

def cache_get(key):
    with _cache_lock:
        return cache.get(key)

def cache_set(key, value):
    with _cache_lock:
        cache[key] = value

def cache_clear():
    with _cache_lock:
        cache.clear()
    logger.info("Cache invalidé")

def system_metrics():
    """Retourne CPU/RAM; fonctionne sans psutil si le module manque."""
    try:
        import psutil
        process = psutil.Process()
        return {
            "cpu_percent": psutil.cpu_percent(interval=None),
            "memory_percent": psutil.virtual_memory().percent,
            "process_memory_mb": round(process.memory_info().rss / 1024 / 1024, 1),
            "queue_size": task_queue._queue.qsize(),
        }
    except Exception as exc:
        logger.warning("Monitoring indisponible: %s", exc)
        return {
            "cpu_percent": None,
            "memory_percent": None,
            "process_memory_mb": None,
            "queue_size": task_queue._queue.qsize(),
        }


def safe_callback(callback):
    """Wrap a future callback so unexpected callback errors are logged."""
    def wrapped(future):
        try:
            return callback(future)
        except Exception:
            logger.exception("Erreur dans un callback asynchrone")
    return wrapped
