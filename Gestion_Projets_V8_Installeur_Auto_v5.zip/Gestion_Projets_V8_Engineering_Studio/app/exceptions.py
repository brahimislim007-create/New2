class GestionProjetsError(Exception):
    """Base exception for the application."""

class ConfigurationError(GestionProjetsError):
    pass

class AuthenticationError(GestionProjetsError):
    pass

class AuthorizationError(GestionProjetsError):
    pass

class DatabaseOperationError(GestionProjetsError):
    pass
