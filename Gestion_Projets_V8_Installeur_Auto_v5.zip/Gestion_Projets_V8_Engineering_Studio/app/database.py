from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from app.config import load_env
import os

load_env()
DATABASE_URL = os.getenv("DATABASE_URL")

# V7 sample files sometimes used the psycopg2 dialect while this release
# ships psycopg v3. Normalize legacy PostgreSQL URLs without changing .env.
if DATABASE_URL:
    if DATABASE_URL.startswith("postgresql+psycopg2://"):
        DATABASE_URL = DATABASE_URL.replace("postgresql+psycopg2://", "postgresql+psycopg://", 1)
    elif DATABASE_URL.startswith("postgresql://"):
        DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

if not DATABASE_URL:
    raise RuntimeError(
        "DATABASE_URL est absent. Copiez .env.example vers .env puis configurez PostgreSQL."
    )

class Base(DeclarativeBase):
    pass

engine_options = {"pool_pre_ping": True}
if not DATABASE_URL.startswith("sqlite"):
    engine_options.update({
        "pool_recycle": 1800,
        "pool_size": 10,
        "max_overflow": 20,
        "pool_timeout": 30,
    })

engine = create_engine(DATABASE_URL, **engine_options)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
