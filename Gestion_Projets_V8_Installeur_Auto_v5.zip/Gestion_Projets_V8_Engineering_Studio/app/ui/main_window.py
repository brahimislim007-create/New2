from __future__ import annotations
import threading
from datetime import date

from PySide6.QtCore import QDate, QUrl, Signal
from PySide6.QtGui import QAction, QDesktopServices
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QMessageBox, QStatusBar, QSplitter, QListWidget, QStackedWidget,
    QTextEdit, QTableWidget, QTableWidgetItem, QPushButton, QLineEdit,
    QDialog, QFormLayout, QDialogButtonBox, QSpinBox, QDoubleSpinBox,
    QDateEdit, QComboBox, QFileDialog, QTabWidget, QGroupBox, QHeaderView,
    QAbstractItemView, QInputDialog,
)

from app.ui.ribbon import RibbonBar
from app.resilience import system_metrics, logger
from app.config import application_directory
from app.services.security_service import has_permission, list_users, create_user, ROLES
from app.services.backup_service import backup_database
from app.services.project_service import (
    list_projects, list_headquarters, create_headquarters, dashboard_metrics,
    create_project, PROJECT_STATUSES,
)
from app.services.v8_service import (
    add_record, list_records, delete_record, save_custom_field, list_custom_fields,
    update_project, delete_project, finance_summary,
)
from app.services.document_service import attach_file, list_attachments, resolve_attachment, extract_text, analyze_spreadsheet
from app.reports.report_service import export_pdf, export_excel, export_word

FINANCE_TABLES = [
    ("budgets", "Budgets", ["ID", "Intitulé", "Montant", "Devise", "Date"],
     ["id", "label", "amount", "currency", "revision_date"]),
    ("contracts", "Marchés", ["ID", "Référence", "Objet", "Titulaire", "Montant", "Statut"],
     ["id", "reference", "title", "supplier", "amount", "status"]),
    ("invoices", "Factures", ["ID", "Référence", "Type", "Tiers", "Montant", "Échéance", "Statut"],
     ["id", "reference", "invoice_type", "party", "amount", "due_date", "status"]),
    ("expenses", "Dépenses", ["ID", "Catégorie", "Description", "Montant", "Date", "Fournisseur"],
     ["id", "category", "description", "amount", "expense_date", "supplier"]),
    ("commitments", "Engagements", ["ID", "Référence", "Description", "Montant", "Date", "Statut"],
     ["id", "reference", "description", "amount", "commitment_date", "status"]),
    ("resources", "Ressources", ["ID", "Nom", "Type", "Quantité", "Unité", "Début", "Fin"],
     ["id", "name", "resource_type", "quantity", "unit", "start_date", "end_date"]),
]
TASK_FIELDS = ["id", "title", "start_date", "end_date", "progress", "status", "assignee"]
SUMMARY_LABELS = {"budgets": "Budgets", "contracts": "Marchés", "invoices": "Factures",
                  "expenses": "Dépenses", "commitments": "Engagements"}


def fmt_totals(totals: dict) -> str:
    """Affiche les totaux par devise sans jamais additionner des devises différentes."""
    if not totals:
        return "0"
    return " | ".join(f"{value:,.3f} {currency}" for currency, value in sorted(totals.items()))


def _fmt_value(value):
    return "—" if value is None else str(value)


class ProjectDialog(QDialog):
    def __init__(self, parent=None, project=None, headquarters=()):
        super().__init__(parent)
        self.setWindowTitle("Modifier le projet" if project else "Nouveau projet")
        self.setMinimumWidth(460)
        form = QFormLayout(self)
        self.code = QLineEdit(getattr(project, "code", "") or "")
        self.name = QLineEdit(getattr(project, "name", "") or "")
        self.progress = QSpinBox(); self.progress.setRange(0, 100); self.progress.setSuffix(" %")
        self.progress.setValue(int(getattr(project, "progress", 0) or 0))
        self.status = QComboBox(); self.status.addItems(list(PROJECT_STATUSES))
        current_status = getattr(project, "status", None) or "Nouveau"
        self.status.setCurrentText(current_status if current_status in PROJECT_STATUSES else "Nouveau")
        self.start = self._date_edit(getattr(project, "start_date", None))
        self.end = self._date_edit(getattr(project, "end_date", None))
        self.description = QTextEdit(getattr(project, "description", "") or ""); self.description.setMaximumHeight(100)
        self.headquarters = QComboBox(); self.headquarters.addItem("— Aucun —", None)
        for hq in headquarters: self.headquarters.addItem(hq.name, hq.id)
        if getattr(project, "headquarters_id", None) is not None:
            idx = self.headquarters.findData(project.headquarters_id)
            if idx >= 0: self.headquarters.setCurrentIndex(idx)
        form.addRow("Code *", self.code); form.addRow("Nom du projet *", self.name)
        form.addRow("Avancement", self.progress); form.addRow("Statut", self.status)
        form.addRow("Date de début", self.start); form.addRow("Date de fin", self.end)
        form.addRow("Siège / maître d'ouvrage", self.headquarters); form.addRow("Description", self.description)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)

    @staticmethod
    def _date_edit(value):
        edit = QDateEdit(); edit.setCalendarPopup(True); edit.setDisplayFormat("dd/MM/yyyy")
        edit.setDateRange(QDate(2000, 1, 1), QDate(2100, 12, 31))
        edit.setDate(QDate(value.year, value.month, value.day) if isinstance(value, date) else QDate.currentDate())
        return edit

    def values(self):
        return {
            "code": self.code.text().strip(), "name": self.name.text().strip(),
            "progress": self.progress.value(), "status": self.status.currentText(),
            "start_date": self.start.date().toString("yyyy-MM-dd"),
            "end_date": self.end.date().toString("yyyy-MM-dd"),
            "headquarters_id": self.headquarters.currentData(),
            "description": self.description.toPlainText().strip(),
        }


class HeadquartersDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nouveau siège / maître d'ouvrage")
        self.setMinimumWidth(420)
        form = QFormLayout(self)
        self.name = QLineEdit(); self.address = QLineEdit(); self.city = QLineEdit()
        form.addRow("Nom *", self.name); form.addRow("Adresse", self.address); form.addRow("Ville", self.city)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)

    def values(self):
        return {"name": self.name.text().strip(), "address": self.address.text().strip(), "city": self.city.text().strip()}


class UserDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nouvel utilisateur")
        self.setMinimumWidth(420)
        form = QFormLayout(self)
        self.username = QLineEdit()
        self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password)
        self.confirm = QLineEdit(); self.confirm.setEchoMode(QLineEdit.Password)
        self.role = QComboBox(); self.role.addItems(sorted(ROLES)); self.role.setCurrentText("USER")
        form.addRow("Nom d'utilisateur *", self.username)
        form.addRow("Mot de passe * (10 caractères min.)", self.password)
        form.addRow("Confirmer le mot de passe *", self.confirm)
        form.addRow("Rôle", self.role)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)

    def values(self):
        return {"username": self.username.text().strip(), "password": self.password.text(),
                "confirm": self.confirm.text(), "role": self.role.currentText()}


class UsersDialog(QDialog):
    """Gestion des comptes, réservée aux administrateurs (permission users.manage)."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Utilisateurs")
        self.setMinimumSize(560, 360)
        layout = QVBoxLayout(self)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Utilisateur", "Rôle", "Actif", "Créé le"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)
        row = QHBoxLayout(); add = QPushButton("Nouvel utilisateur"); add.clicked.connect(self.add_user)
        close = QPushButton("Fermer"); close.clicked.connect(self.accept)
        row.addWidget(add); row.addStretch(1); row.addWidget(close); layout.addLayout(row)
        self.reload()

    def reload(self):
        users = list_users()
        self.table.setRowCount(len(users))
        for r, u in enumerate(users):
            values = [u.username, u.role, "Oui" if u.is_active else "Non",
                      u.created_at.strftime("%d/%m/%Y %H:%M") if u.created_at else "—"]
            for c, value in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))

    def add_user(self):
        dlg = UserDialog(self)
        if dlg.exec() != QDialog.Accepted: return
        data = dlg.values()
        if data["password"] != data["confirm"]:
            QMessageBox.warning(self, "Mot de passe", "Les deux mots de passe ne correspondent pas."); return
        try:
            create_user(data["username"], data["password"], data["role"])
            self.reload()
        except Exception as exc:
            QMessageBox.critical(self, "Création impossible", str(exc))


class RecordDialog(QDialog):
    """Saisie générique : planning, finances et ressources."""
    FIELDS = {
        "tasks": [("title", "Intitulé *", "text"), ("description", "Description", "text"), ("start_date", "Début", "date"), ("end_date", "Fin", "date"), ("progress", "Avancement (%)", "percent"), ("status", "Statut", "combo:À faire|En cours|Bloquée|Terminée"), ("priority", "Priorité", "combo:Basse|Normale|Haute|Critique"), ("assignee", "Responsable", "text")],
        "budgets": [("label", "Intitulé *", "text"), ("amount", "Montant *", "number"), ("currency", "Devise", "combo:TND|EUR|USD"), ("revision_date", "Date", "date"), ("notes", "Notes", "text")],
        "contracts": [("reference", "Référence *", "text"), ("title", "Objet du marché *", "text"), ("supplier", "Titulaire", "text"), ("amount", "Montant *", "number"), ("currency", "Devise", "combo:TND|EUR|USD"), ("status", "Statut", "combo:Préparation|Publié|Attribué|Signé|En cours|Clôturé|Résilié"), ("signed_date", "Date de signature", "date"), ("start_date", "Début", "date"), ("end_date", "Fin", "date"), ("notes", "Notes", "text")],
        "invoices": [("reference", "Référence *", "text"), ("invoice_type", "Type", "combo:Dépense|Recette"), ("party", "Fournisseur / bénéficiaire", "text"), ("amount", "Montant *", "number"), ("currency", "Devise", "combo:TND|EUR|USD"), ("invoice_date", "Date facture", "date"), ("due_date", "Échéance", "date"), ("status", "Statut", "combo:En attente|Payée|Partiellement payée|Annulée"), ("notes", "Notes", "text")],
        "expenses": [("category", "Catégorie *", "text"), ("description", "Description *", "text"), ("amount", "Montant *", "number"), ("currency", "Devise", "combo:TND|EUR|USD"), ("expense_date", "Date", "date"), ("supplier", "Fournisseur", "text"), ("invoice_reference", "Référence facture", "text")],
        "commitments": [("reference", "Référence *", "text"), ("description", "Description *", "text"), ("amount", "Montant *", "number"), ("currency", "Devise", "combo:TND|EUR|USD"), ("commitment_date", "Date", "date"), ("status", "Statut", "combo:Engagé|Partiellement exécuté|Exécuté|Annulé")],
        "resources": [("name", "Ressource *", "text"), ("resource_type", "Type", "combo:Personnel|Équipement|Matériau|Sous-traitant"), ("quantity", "Quantité", "number"), ("unit", "Unité", "text"), ("start_date", "Début", "date"), ("end_date", "Fin", "date"), ("notes", "Notes", "text")],
    }

    def __init__(self, kind, parent=None):
        super().__init__(parent); self.kind = kind; self.widgets = {}
        self.setWindowTitle("Ajouter une tâche" if kind == "tasks" else "Ajouter un enregistrement")
        self.setMinimumWidth(430); form = QFormLayout(self)
        for key, label, typ in self.FIELDS[kind]:
            if typ == "text": widget = QLineEdit()
            elif typ == "number":
                widget = QDoubleSpinBox(); widget.setRange(0, 99999999999); widget.setDecimals(3); widget.setGroupSeparatorShown(True)
            elif typ == "percent":
                widget = QSpinBox(); widget.setRange(0, 100); widget.setSuffix(" %")
            elif typ == "date":
                widget = QDateEdit(); widget.setCalendarPopup(True); widget.setDisplayFormat("dd/MM/yyyy"); widget.setDate(QDate.currentDate())
            else:
                widget = QComboBox(); widget.addItems(typ.split(":", 1)[1].split("|"))
            self.widgets[key] = widget; form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)

    def values(self):
        data = {}
        for key, widget in self.widgets.items():
            if isinstance(widget, QLineEdit): data[key] = widget.text().strip()
            elif isinstance(widget, (QDoubleSpinBox, QSpinBox)): data[key] = widget.value()
            elif isinstance(widget, QDateEdit): data[key] = widget.date().toString("yyyy-MM-dd")
            elif isinstance(widget, QComboBox): data[key] = widget.currentText()
        return data


class MainWindow(QMainWindow):
    # Résultats des chargements en arrière-plan : (résultat, erreur, callback).
    # Le signal est émis depuis un thread de travail et livré dans le thread de l'interface.
    bgDone = Signal(object, object, object)

    def __init__(self, current_user=None):
        super().__init__()
        self.current_user = current_user
        self.setWindowTitle("Gestion Projets V8 Engineering Studio")
        self.resize(1500, 900)
        self.projects = []
        self.headquarters = []
        self.bgDone.connect(self._on_bg_done)
        self._create_actions(); self._build_ui(); self._build_ribbon(); self._build_statusbar()
        self.refresh_data()

    # ------------------------------------------------------------------ utilitaires
    def _can(self, permission, message):
        if has_permission(self.current_user, permission):
            return True
        QMessageBox.warning(self, "Accès refusé", message)
        return False

    def _run_bg(self, func, on_done, *args):
        """Exécute une fonction de base de données hors de l'interface."""
        def worker():
            try:
                result, error = func(*args), None
            except Exception as exc:
                logger.exception("Erreur en arrière-plan")
                result, error = None, exc
            self.bgDone.emit(result, error, on_done)
        threading.Thread(target=worker, name="UiLoader", daemon=True).start()

    def _on_bg_done(self, result, error, on_done):
        on_done(result, error)

    def _create_actions(self):
        self.act_new_project = QAction("Nouveau projet", self); self.act_new_project.triggered.connect(self.new_project)
        self.act_new_hq = QAction("Nouveau siège", self); self.act_new_hq.triggered.connect(self.new_headquarters)
        self.act_projects = QAction("Projets", self); self.act_projects.triggered.connect(lambda: self.show_page(1))
        self.act_dashboard = QAction("Tableau de bord", self); self.act_dashboard.triggered.connect(lambda: self.show_page(0))
        self.act_planning = QAction("Planning", self); self.act_planning.triggered.connect(lambda: self.show_page(2))
        self.act_finance = QAction("Finances & marchés", self); self.act_finance.triggered.connect(lambda: self.show_page(3))
        self.act_documents = QAction("Documents", self); self.act_documents.triggered.connect(lambda: self.show_page(4))
        self.act_reports = QAction("Rapports", self); self.act_reports.triggered.connect(lambda: self.show_page(5))
        self.act_refresh = QAction("Actualiser", self); self.act_refresh.triggered.connect(self.refresh_data)
        self.act_backup = QAction("Sauvegarder", self); self.act_backup.setEnabled(has_permission(self.current_user, "backup.run")); self.act_backup.triggered.connect(self.run_backup)
        self.act_users = QAction("Utilisateurs", self); self.act_users.setEnabled(has_permission(self.current_user, "users.manage")); self.act_users.triggered.connect(self.show_users)
        self.act_about = QAction("À propos", self); self.act_about.triggered.connect(self.show_about)

    def _build_ui(self):
        central = QWidget(); layout = QVBoxLayout(central); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(0)
        self.ribbon = RibbonBar(self); layout.addWidget(self.ribbon)
        splitter = QSplitter(); self.navigation = QListWidget(); self.navigation.addItems(["Tableau de bord", "Projets", "Planning & tâches", "Finances & marchés", "Documents", "Rapports"]); self.navigation.setMaximumWidth(230)
        self.pages = QStackedWidget()
        for page in (self._dashboard_page(), self._projects_page(), self._planning_page(),
                     self._finance_page(), self._documents_page(), self._reports_page()):
            self.pages.addWidget(page)
        self.navigation.currentRowChanged.connect(self.show_page); self.navigation.setCurrentRow(0)
        splitter.addWidget(self.navigation); splitter.addWidget(self.pages); splitter.setStretchFactor(1, 1); layout.addWidget(splitter, 1)
        self.activity = QTextEdit(); self.activity.setReadOnly(True); self.activity.setMaximumHeight(75)
        self.activity.setPlainText(f"Gestion Projets V8 démarré. Utilisateur : {getattr(self.current_user, 'username', 'inconnu')}")
        layout.addWidget(self.activity); self.setCentralWidget(central)

    def _dashboard_page(self):
        page = QWidget(); outer = QVBoxLayout(page)
        outer.addWidget(QLabel("<h1>Tableau de bord des projets</h1><p>Vue consolidée du portefeuille, de l'avancement et des engagements.</p>"))
        grid = QGridLayout(); self.metric_labels = {}
        for idx, (key, label) in enumerate([("total", "Projets"), ("active", "En cours"), ("completed", "Terminés"), ("average_progress", "Avancement moyen"), ("budget", "Budgets (par devise)"), ("expenses", "Dépenses (par devise)")]):
            card = QGroupBox(label); box = QVBoxLayout(card); value = QLabel("—"); value.setObjectName("metricValue"); value.setWordWrap(True)
            box.addWidget(value); self.metric_labels[key] = value; grid.addWidget(card, idx // 3, idx % 3)
        outer.addLayout(grid)
        outer.addWidget(QLabel("<h3>Projets récents</h3>")); self.dashboard_table = QTableWidget(0, 5); self.dashboard_table.setHorizontalHeaderLabels(["Code", "Projet", "Statut", "Avancement", "Fin prévue"]); self._prepare_table(self.dashboard_table); outer.addWidget(self.dashboard_table)
        outer.addStretch(1); return page

    def _projects_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("<h1>Gestion des projets</h1>"))
        row = QHBoxLayout(); self.project_search = QLineEdit(); self.project_search.setPlaceholderText("Rechercher par code ou nom…"); self.project_search.textChanged.connect(self.populate_projects_table); row.addWidget(self.project_search)
        for text, slot in [("Nouveau", self.new_project), ("Nouveau siège", self.new_headquarters), ("Modifier", self.edit_project), ("Supprimer", self.remove_project), ("Champs personnalisés", self.edit_custom_fields), ("Actualiser", self.refresh_data)]:
            b = QPushButton(text); b.clicked.connect(slot); row.addWidget(b)
        layout.addLayout(row); self.project_table = QTableWidget(0, 8); self.project_table.setHorizontalHeaderLabels(["ID", "Code", "Projet", "Statut", "Avancement", "Début", "Fin", "Siège"]); self._prepare_table(self.project_table); layout.addWidget(self.project_table); return page

    def _planning_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("<h1>Planning et tâches</h1><p>Suivi des tâches, responsables, priorités et dates. Les données sont liées au projet sélectionné.</p>"))
        row = QHBoxLayout(); self.task_project = QComboBox(); row.addWidget(QLabel("Projet :")); row.addWidget(self.task_project, 1)
        add = QPushButton("Ajouter une tâche"); add.clicked.connect(lambda: self.add_record_dialog("tasks")); delete = QPushButton("Supprimer la tâche sélectionnée"); delete.clicked.connect(lambda: self.delete_selected_record("tasks", self.task_table))
        row.addWidget(add); row.addWidget(delete); layout.addLayout(row)
        self.task_table = QTableWidget(0, 7); self.task_table.setHorizontalHeaderLabels(["ID", "Tâche", "Début", "Fin", "Avancement", "Statut", "Responsable"]); self._prepare_table(self.task_table); layout.addWidget(self.task_table); self.task_project.currentIndexChanged.connect(self.load_tasks); return page

    def _finance_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("<h1>Finances, marchés et ressources</h1><p>Budgets, contrats, factures, dépenses, engagements et moyens du projet.</p>"))
        row = QHBoxLayout(); self.finance_project = QComboBox(); row.addWidget(QLabel("Projet :")); row.addWidget(self.finance_project, 1); layout.addLayout(row)
        self.finance_summary_label = QLabel("Sélectionnez un projet pour afficher ses données financières."); self.finance_summary_label.setWordWrap(True); layout.addWidget(self.finance_summary_label)
        self.finance_tabs = QTabWidget(); self.finance_tables = {}
        for kind, title, headers, _fields in FINANCE_TABLES:
            tab = QWidget(); box = QVBoxLayout(tab); bar = QHBoxLayout(); new = QPushButton("Ajouter"); new.clicked.connect(lambda checked=False, k=kind: self.add_record_dialog(k)); delete = QPushButton("Supprimer la sélection"); delete.clicked.connect(lambda checked=False, k=kind: self.delete_selected_record(k, self.finance_tables[k])); bar.addWidget(new); bar.addWidget(delete); bar.addStretch(); box.addLayout(bar)
            table = QTableWidget(0, len(headers)); table.setHorizontalHeaderLabels(headers); self._prepare_table(table); box.addWidget(table); self.finance_tables[kind] = table; self.finance_tabs.addTab(tab, title)
        layout.addWidget(self.finance_tabs); self.finance_project.currentIndexChanged.connect(self.load_finance); return page

    def _documents_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("<h1>Documents et pièces jointes</h1><p>Conservez les fichiers du projet, vérifiez leur empreinte SHA-256 et extrayez le texte des PDF, Word et Excel.</p>"))
        row = QHBoxLayout(); self.document_project = QComboBox(); row.addWidget(QLabel("Projet :")); row.addWidget(self.document_project, 1)
        upload = QPushButton("Joindre un fichier"); upload.clicked.connect(self.upload_document); open_file = QPushButton("Ouvrir le fichier"); open_file.clicked.connect(self.open_selected_document); analyze = QPushButton("Analyser Excel"); analyze.clicked.connect(self.analyze_selected_document); read = QPushButton("Extraire le texte"); read.clicked.connect(self.read_selected_document); row.addWidget(upload); row.addWidget(open_file); row.addWidget(analyze); row.addWidget(read); layout.addLayout(row)
        self.document_table = QTableWidget(0, 5); self.document_table.setHorizontalHeaderLabels(["ID", "Fichier", "Type", "Taille (octets)", "SHA-256"]); self._prepare_table(self.document_table); layout.addWidget(self.document_table, 2)
        self.document_preview = QTextEdit(); self.document_preview.setReadOnly(True); self.document_preview.setPlaceholderText("Aperçu du texte extrait ou analyse du classeur…"); layout.addWidget(self.document_preview, 2)
        self.document_project.currentIndexChanged.connect(self.load_documents); return page

    def _reports_page(self):
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("<h1>Rapports et exports</h1><p>Générez des rapports de synthèse en PDF, Excel ou Word à partir des données de projet.</p>"))
        row = QHBoxLayout(); self.report_project = QComboBox(); row.addWidget(QLabel("Projet :")); row.addWidget(self.report_project, 1)
        for label, ext, fn in [("Exporter PDF", "pdf", export_pdf), ("Exporter Excel", "xlsx", export_excel), ("Exporter Word", "docx", export_word)]:
            b = QPushButton(label); b.clicked.connect(lambda checked=False, f=fn, e=ext: self.export_report(f, e)); row.addWidget(b)
        layout.addLayout(row)
        self.report_info = QLabel(f"Les rapports sont enregistrés dans : {application_directory() / 'reports'}"); self.report_info.setWordWrap(True); layout.addWidget(self.report_info); layout.addStretch(1); return page

    def _prepare_table(self, table):
        table.setSelectionBehavior(QAbstractItemView.SelectRows); table.setSelectionMode(QAbstractItemView.SingleSelection); table.setEditTriggers(QAbstractItemView.NoEditTriggers); table.setAlternatingRowColors(True); table.verticalHeader().setVisible(False); table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); table.horizontalHeader().setStretchLastSection(True)

    def _build_ribbon(self):
        accueil = self.ribbon.add_page("ACCUEIL"); g = accueil.add_group("Démarrage"); g.add_action(self.act_dashboard); g.add_action(self.act_new_project); g.add_action(self.act_refresh)
        gp = self.ribbon.add_page("PROJETS"); g = gp.add_group("Portefeuille"); g.add_action(self.act_projects); g.add_action(self.act_planning); g.add_action(self.act_new_hq)
        gf = self.ribbon.add_page("FINANCES"); g = gf.add_group("Suivi financier"); g.add_action(self.act_finance)
        gd = self.ribbon.add_page("DOCUMENTS"); g = gd.add_group("Fichiers"); g.add_action(self.act_documents); g = gd.add_group("Rapports"); g.add_action(self.act_reports)
        ga = self.ribbon.add_page("ADMINISTRATION"); g = ga.add_group("Système"); g.add_action(self.act_backup); g.add_action(self.act_users)
        gh = self.ribbon.add_page("AIDE"); g = gh.add_group("Informations"); g.add_action(self.act_about)

    def _build_statusbar(self):
        bar = QStatusBar(self); self.user_label = QLabel(f"Utilisateur : {getattr(self.current_user, 'username', '?')} | Rôle : {getattr(self.current_user, 'role', '?')}"); self.metrics_label = QLabel("CPU: — | RAM: —")
        bar.addWidget(self.user_label); bar.addPermanentWidget(self.metrics_label); self.setStatusBar(bar)

    def show_page(self, index):
        if 0 <= index < self.pages.count():
            self.pages.setCurrentIndex(index)
            if self.navigation.currentRow() != index: self.navigation.setCurrentRow(index)

    def selected_project_id(self):
        row = self.project_table.currentRow()
        if row < 0: return None
        try: return int(self.project_table.item(row, 0).text())
        except (AttributeError, ValueError): return None

    # ------------------------------------------------------------------ chargement
    def refresh_data(self):
        self._run_bg(self._load_overview, self._apply_overview)

    @staticmethod
    def _load_overview():
        return {
            "projects": list_projects(),
            "headquarters": list_headquarters(),
            "metrics": dashboard_metrics(),
            "finance": finance_summary(),
        }

    def _apply_overview(self, result, error):
        if error is not None:
            self.activity.append(f"Erreur d'actualisation : {error}")
            QMessageBox.critical(self, "Erreur de données", str(error))
        else:
            self.projects = result["projects"]; self.headquarters = result["headquarters"]
            self.populate_projects_table(); self.refresh_dashboard(result["metrics"], result["finance"])
            self.populate_project_combos()
            self.activity.append("Données actualisées.")
        self.update_system_status()

    def populate_project_combos(self):
        combos = [self.task_project, self.finance_project, self.document_project, self.report_project]
        for combo in combos:
            current = combo.currentData(); combo.blockSignals(True); combo.clear()
            for p in self.projects: combo.addItem(f"{p.code} — {p.name}", p.id)
            if current is not None:
                idx = combo.findData(current)
                if idx >= 0: combo.setCurrentIndex(idx)
            combo.blockSignals(False)
        self.load_tasks(); self.load_finance(); self.load_documents()

    def populate_projects_table(self):
        if not hasattr(self, "project_table"): return
        hq_names = {h.id: h.name for h in self.headquarters}
        filter_text = self.project_search.text().casefold()
        rows = [p for p in self.projects if not filter_text or filter_text in f"{p.code} {p.name}".casefold()]
        self.project_table.setRowCount(len(rows))
        for r, p in enumerate(rows):
            values = [p.id, p.code, p.name, p.status, f"{p.progress}%", _fmt_value(p.start_date), _fmt_value(p.end_date),
                      hq_names.get(p.headquarters_id, "—")]
            for c, value in enumerate(values): self.project_table.setItem(r, c, QTableWidgetItem(str(value)))

    def refresh_dashboard(self, metrics, finance):
        if not hasattr(self, "metric_labels"): return
        values = {"total": str(metrics["total"]), "active": str(metrics["active"]), "completed": str(metrics["completed"]),
                  "average_progress": f'{metrics["average_progress"]} %',
                  "budget": fmt_totals(finance["budgets"]), "expenses": fmt_totals(finance["expenses"])}
        for key, value in values.items(): self.metric_labels[key].setText(value)
        latest = self.projects[:10]; self.dashboard_table.setRowCount(len(latest))
        for r, p in enumerate(latest):
            vals = [p.code, p.name, p.status, f"{p.progress}%", _fmt_value(p.end_date)]
            for c, value in enumerate(vals): self.dashboard_table.setItem(r, c, QTableWidgetItem(str(value)))

    def load_tasks(self):
        if not hasattr(self, "task_table"): return
        pid = self.task_project.currentData()
        if not pid:
            self._fill_table(self.task_table, [], TASK_FIELDS); return
        self._run_bg(lambda: list_records("tasks", int(pid)), lambda r, e: self._apply_tasks(pid, r, e))

    def _apply_tasks(self, pid, records, error):
        if self.task_project.currentData() != pid: return  # réponse périmée
        if error is not None:
            self.activity.append(f"Erreur de chargement des tâches : {error}"); return
        self._fill_table(self.task_table, records, TASK_FIELDS)

    def load_finance(self):
        if not hasattr(self, "finance_tables"): return
        pid = self.finance_project.currentData()
        if not pid:
            for kind, _t, _h, fields in FINANCE_TABLES: self._fill_table(self.finance_tables[kind], [], fields)
            self.finance_summary_label.setText("Sélectionnez un projet pour afficher ses données financières.")
            return
        def job():
            records = {kind: list_records(kind, int(pid)) for kind, _t, _h, _f in FINANCE_TABLES}
            return records, finance_summary(int(pid))
        self._run_bg(job, lambda r, e: self._apply_finance(pid, r, e))

    def _apply_finance(self, pid, result, error):
        if self.finance_project.currentData() != pid: return
        if error is not None:
            self.activity.append(f"Erreur de chargement financier : {error}"); return
        records, summary = result
        for kind, _title, _headers, fields in FINANCE_TABLES:
            self._fill_table(self.finance_tables[kind], records[kind], fields)
        self.finance_summary_label.setText(" | ".join(f"{SUMMARY_LABELS[k]} : {fmt_totals(v)}" for k, v in summary.items()))

    def load_documents(self):
        if not hasattr(self, "document_table"): return
        pid = self.document_project.currentData()
        if not pid:
            self.document_table.setRowCount(0); return
        self._run_bg(lambda: list_attachments(int(pid)), lambda r, e: self._apply_documents(pid, r, e))

    def _apply_documents(self, pid, items, error):
        if self.document_project.currentData() != pid: return
        if error is not None:
            self.activity.append(f"Erreur de chargement des documents : {error}"); return
        self.document_table.setRowCount(len(items))
        for r, item in enumerate(items):
            for c, val in enumerate([item.id, item.original_name, item.extension, item.file_size, item.sha256]):
                self.document_table.setItem(r, c, QTableWidgetItem(str(val)))

    def _fill_table(self, table, records, fields):
        table.setRowCount(len(records))
        for r, obj in enumerate(records):
            for c, field in enumerate(fields):
                table.setItem(r, c, QTableWidgetItem(_fmt_value(getattr(obj, field, None))))

    # ------------------------------------------------------------------ projets
    def new_project(self):
        if not self._can("projects.write", "Vous n'avez pas l'autorisation de créer un projet."): return
        dlg = ProjectDialog(self, headquarters=self.headquarters)
        if dlg.exec() != QDialog.Accepted: return
        data = dlg.values()
        if not data["code"] or not data["name"]:
            QMessageBox.warning(self, "Champs requis", "Le code et le nom du projet sont obligatoires."); return
        try:
            item = create_project(data["code"], data["name"], data["progress"], data["headquarters_id"],
                                  data["description"], start_date=data["start_date"], end_date=data["end_date"],
                                  status=data["status"])
            self.activity.append(f"Projet créé : {item.code} — {item.name}")
            self.refresh_data()
        except Exception as exc:
            QMessageBox.critical(self, "Création impossible", str(exc))

    def new_headquarters(self):
        if not self._can("headquarters.write", "Vous n'avez pas l'autorisation de créer un siège."): return
        dlg = HeadquartersDialog(self)
        if dlg.exec() != QDialog.Accepted: return
        data = dlg.values()
        if not data["name"]:
            QMessageBox.warning(self, "Champs requis", "Le nom du siège est obligatoire."); return
        try:
            create_headquarters(data["name"], data["address"], data["city"])
            self.activity.append(f"Siège créé : {data['name']}")
            self.refresh_data()
        except Exception as exc:
            QMessageBox.critical(self, "Création impossible", str(exc))

    def edit_project(self):
        if not self._can("projects.write", "Modification non autorisée."): return
        pid = self.selected_project_id()
        if pid is None: QMessageBox.information(self, "Sélection", "Sélectionnez un projet."); return
        project = next((p for p in self.projects if p.id == pid), None)
        if project is None: return
        dlg = ProjectDialog(self, project, headquarters=self.headquarters)
        if dlg.exec() != QDialog.Accepted: return
        data = dlg.values()
        try:
            update_project(pid, **data); self.activity.append(f"Projet modifié : {data['code']}"); self.refresh_data()
        except Exception as exc:
            QMessageBox.critical(self, "Modification impossible", str(exc))

    def remove_project(self):
        if not self._can("projects.write", "Suppression non autorisée."): return
        pid = self.selected_project_id()
        if pid is None: QMessageBox.information(self, "Sélection", "Sélectionnez un projet."); return
        answer = QMessageBox.question(self, "Confirmer", "Supprimer ce projet et toutes ses données V8 associées ?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes:
            try:
                delete_project(pid); self.activity.append(f"Projet supprimé : #{pid}"); self.refresh_data()
            except Exception as exc:
                QMessageBox.critical(self, "Suppression impossible", str(exc))

    def edit_custom_fields(self):
        if not self._can("projects.write", "Modification non autorisée."): return
        pid = self.selected_project_id()
        if pid is None: QMessageBox.information(self, "Sélection", "Sélectionnez d'abord un projet."); return
        name, ok = QInputDialog.getText(self, "Champ personnalisé", "Nom du champ :")
        if not ok or not name.strip(): return
        current = next((f.field_value or "" for f in list_custom_fields(pid) if f.field_name == name.strip()), "")
        value, ok = QInputDialog.getText(self, "Valeur du champ", f"Valeur pour « {name} » :", text=current)
        if ok:
            try:
                save_custom_field(pid, name, value); self.activity.append(f"Champ personnalisé enregistré : {name}")
            except Exception as exc:
                QMessageBox.critical(self, "Erreur", str(exc))

    # ------------------------------------------------------------------ planning & finances
    def _selected_combo_project(self, combo):
        value = combo.currentData()
        if value is None: QMessageBox.information(self, "Projet requis", "Créez ou sélectionnez un projet."); return None
        return int(value)

    def add_record_dialog(self, kind):
        if not self._can("projects.write", "Vous ne disposez pas du droit de modification."): return
        combo = self.task_project if kind == "tasks" else self.finance_project
        pid = self._selected_combo_project(combo)
        if pid is None: return
        dlg = RecordDialog(kind, self)
        if dlg.exec() != QDialog.Accepted: return
        try:
            add_record(kind, pid, **dlg.values())
            self.activity.append(f"Enregistrement ajouté : {kind}")
            self.refresh_data()
        except Exception as exc:
            QMessageBox.critical(self, "Enregistrement impossible", str(exc))

    def delete_selected_record(self, kind, table):
        if not self._can("projects.write", "Suppression non autorisée."): return
        row = table.currentRow()
        if row < 0: QMessageBox.information(self, "Sélection", "Sélectionnez une ligne."); return
        record_id = int(table.item(row, 0).text())
        answer = QMessageBox.question(self, "Confirmer", "Supprimer cet enregistrement ?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes: return
        try:
            delete_record(kind, record_id); self.refresh_data()
        except Exception as exc:
            QMessageBox.critical(self, "Suppression impossible", str(exc))

    # ------------------------------------------------------------------ documents
    def selected_attachment(self):
        row = self.document_table.currentRow()
        if row < 0: return None
        aid = int(self.document_table.item(row, 0).text()); pid = self.document_project.currentData()
        return next((i for i in list_attachments(int(pid)) if i.id == aid), None) if pid else None

    def upload_document(self):
        if not self._can("projects.write", "Vous n'avez pas l'autorisation de joindre des fichiers."): return
        pid = self._selected_combo_project(self.document_project)
        if pid is None: return
        path, _ = QFileDialog.getOpenFileName(self, "Joindre un document", "", "Documents et médias (*.*)")
        if not path: return
        def done(item, error):
            if error is not None:
                QMessageBox.critical(self, "Ajout impossible", str(error)); return
            self.activity.append(f"Document joint : {item.original_name}")
            self.load_documents()
        self._run_bg(attach_file, done, pid, path)

    def open_selected_document(self):
        item = self.selected_attachment()
        if not item: QMessageBox.information(self, "Sélection", "Sélectionnez un fichier."); return
        try: QDesktopServices.openUrl(QUrl.fromLocalFile(str(resolve_attachment(item))))
        except Exception as exc: QMessageBox.critical(self, "Ouverture impossible", str(exc))

    def read_selected_document(self):
        item = self.selected_attachment()
        if not item: QMessageBox.information(self, "Sélection", "Sélectionnez un fichier."); return
        self.document_preview.setPlainText("Extraction en cours…")
        self._run_bg(lambda: extract_text(resolve_attachment(item)),
                     lambda text, e: self.document_preview.setPlainText(
                         text if e is None else f"Lecture impossible : {e}"))

    def analyze_selected_document(self):
        item = self.selected_attachment()
        if not item: QMessageBox.information(self, "Sélection", "Sélectionnez un fichier."); return
        if item.extension not in {".xlsx", ".xlsm"}:
            QMessageBox.information(self, "Format", "Sélectionnez un fichier Excel (.xlsx ou .xlsm)."); return
        self.document_preview.setPlainText("Analyse en cours…")
        def done(report, error):
            if error is not None:
                self.document_preview.setPlainText(f"Analyse impossible : {error}"); return
            lines = [f"Fichier : {report['file']}"]
            for sheet in report["sheets"]:
                lines.append(f"\nFeuille : {sheet['name']} | lignes : {sheet['rows']} | colonnes : {sheet['columns']}")
                for col, stats in sheet["numeric"].items():
                    lines.append(f"  {col}: n={stats['count']}, min={stats['min']:.3f}, max={stats['max']:.3f}, somme={stats['sum']:.3f}, moyenne={stats['average']:.3f}")
            self.document_preview.setPlainText("\n".join(lines))
        self._run_bg(analyze_spreadsheet, done, resolve_attachment(item))

    # ------------------------------------------------------------------ rapports, sauvegarde, administration
    def export_report(self, exporter, extension):
        if not self._can("reports.export", "Export non autorisé."): return
        pid = self.report_project.currentData()
        projects = [p for p in self.projects if p.id == pid] if pid else self.projects
        try:
            path = exporter(projects)
            self.report_info.setText(f"Rapport créé : {path.resolve()}")
            self.activity.append(f"Rapport exporté : {path}")
            QMessageBox.information(self, "Export terminé", f"Fichier créé :\n{path.resolve()}")
        except Exception as exc:
            QMessageBox.critical(self, "Export impossible", str(exc))

    def run_backup(self):
        if not self._can("backup.run", "Sauvegarde non autorisée."): return
        self.activity.append("Sauvegarde en cours…")
        def done(path, error):
            if error is not None:
                QMessageBox.critical(self, "Erreur sauvegarde", str(error)); return
            self.activity.append(f"Sauvegarde créée : {path}")
            QMessageBox.information(self, "Sauvegarde", f"Sauvegarde créée :\n{path}")
        self._run_bg(backup_database, done)

    def show_users(self):
        if not self._can("users.manage", "Gestion des utilisateurs réservée aux administrateurs."): return
        UsersDialog(self).exec()

    def update_system_status(self):
        try:
            m = system_metrics(); self.metrics_label.setText(f"CPU: {m.get('cpu_percent', 0)}% | RAM: {m.get('memory_percent', 0)}%")
        except Exception: self.metrics_label.setText("Monitoring indisponible")

    def show_about(self):
        QMessageBox.information(self, "À propos", "Gestion Projets V8 Engineering Studio\n\nPortefeuille de projets, planning, suivi financier, pièces jointes, extraction documentaire et rapports.\n\nLes résultats techniques et financiers restent soumis à validation professionnelle.")
