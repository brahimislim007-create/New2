from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from app.services.security_service import authenticate

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.user = None
        self.setWindowTitle("Gestion Projets V8 Engineering Studio - Connexion")
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Connexion sécurisée</h2>"))
        self.username = QLineEdit(); self.username.setPlaceholderText("Nom d'utilisateur")
        self.password = QLineEdit(); self.password.setPlaceholderText("Mot de passe"); self.password.setEchoMode(QLineEdit.Password)
        button = QPushButton("Se connecter")
        button.clicked.connect(self.login)
        self.password.returnPressed.connect(self.login)
        layout.addWidget(self.username); layout.addWidget(self.password); layout.addWidget(button)

    def login(self):
        user = authenticate(self.username.text(), self.password.text())
        if not user:
            QMessageBox.warning(self, "Connexion refusée", "Identifiants incorrects ou compte temporairement verrouillé.")
            return
        self.user = user
        self.accept()
