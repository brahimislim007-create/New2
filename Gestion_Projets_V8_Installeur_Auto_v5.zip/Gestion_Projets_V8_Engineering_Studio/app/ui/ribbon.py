from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabBar, QStackedWidget,
    QGroupBox, QToolButton, QSizePolicy
)

class RibbonButton(QToolButton):
    def __init__(self, text, action=None, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        self.setMinimumSize(76, 58)
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        if action:
            self.setDefaultAction(action)

class RibbonGroup(QGroupBox):
    def __init__(self, title, parent=None):
        super().__init__(title, parent)
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(6, 4, 6, 4)
        self.layout.setSpacing(4)

    def add_action(self, action, text=None):
        button = RibbonButton(text or action.text(), action, self)
        self.layout.addWidget(button)
        return button

class RibbonPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(4, 4, 4, 4)
        self.layout.setSpacing(6)
        self.layout.addStretch(1)

    def add_group(self, title):
        group = RibbonGroup(title, self)
        self.layout.insertWidget(self.layout.count()-1, group)
        return group

class RibbonBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tabs = QTabBar()
        self.tabs.setExpanding(False)
        self.tabs.setDocumentMode(True)
        self.stack = QStackedWidget()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.tabs)
        layout.addWidget(self.stack)

        self.tabs.currentChanged.connect(self.stack.setCurrentIndex)

    def add_page(self, title):
        page = RibbonPage(self)
        self.tabs.addTab(title)
        self.stack.addWidget(page)
        return page
