from pathlib import Path
from datetime import datetime

from app.config import application_directory
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from xml.sax.saxutils import escape

from openpyxl import Workbook
from docx import Document

FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")

def _safe_cell(value):
    """Empêche qu'un texte saisi (ex. « =HYPERLINK(...) ») soit interprété comme formule Excel."""
    if isinstance(value, str) and value.startswith(FORMULA_PREFIXES):
        return "'" + value
    return value

def _report_dir() -> Path:
    folder = application_directory() / "reports"
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def export_pdf(projects):
    path = _report_dir() / f"projects_{datetime.now():%Y%m%d_%H%M%S}.pdf"
    styles = getSampleStyleSheet()
    story = [Paragraph("Gestion Projets V8 - Rapport", styles["Title"]), Spacer(1, 12)]
    for p in projects:
        story.append(Paragraph(
            f"<b>{escape(str(p.code))}</b> - {escape(str(p.name))} | {p.progress}% | {escape(str(p.status))}",
            styles["BodyText"]))
        story.append(Spacer(1, 6))
    SimpleDocTemplate(str(path), pagesize=A4).build(story)
    return path

def export_excel(projects):
    path = _report_dir() / f"projects_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    wb = Workbook(); ws = wb.active; ws.title = "Projets"
    ws.append(["ID", "Code", "Projet", "Avancement", "Statut"])
    for p in projects:
        ws.append([_safe_cell(v) for v in (p.id, p.code, p.name, p.progress, p.status)])
    wb.save(path)
    return path

def export_word(projects):
    path = _report_dir() / f"projects_{datetime.now():%Y%m%d_%H%M%S}.docx"
    doc = Document()
    doc.add_heading("Gestion Projets V8 - Rapport", 0)
    table = doc.add_table(rows=1, cols=5)
    for cell, title in zip(table.rows[0].cells, ["ID","Code","Projet","Avancement","Statut"]):
        cell.text = title
    for p in projects:
        row = table.add_row().cells
        for cell, value in zip(row, [p.id,p.code,p.name,f"{p.progress}%",p.status]):
            cell.text = str(value)
    doc.save(path)
    return path
