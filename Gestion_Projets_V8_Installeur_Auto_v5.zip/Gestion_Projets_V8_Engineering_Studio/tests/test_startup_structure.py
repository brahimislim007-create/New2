import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestStartupStructure(unittest.TestCase):
    def test_main_registers_models_before_schema_creation(self):
        text = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("import app.models", text)
        self.assertIn("Base.metadata.create_all", text)
        self.assertLess(
            text.index("import app.models"),
            text.index("Base.metadata.create_all")
        )

    def test_all_python_files_have_valid_syntax(self):
        for path in ROOT.rglob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

if __name__ == "__main__":
    unittest.main()
