import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestV8Structure(unittest.TestCase):
    def test_v8_services_exist(self):
        self.assertTrue((ROOT / "app/services/v8_service.py").is_file())
        self.assertTrue((ROOT / "app/services/document_service.py").is_file())

    def test_v8_models_are_registered(self):
        content = (ROOT / "app/models/__init__.py").read_text(encoding="utf-8")
        for model in ("ProjectCustomField", "ProjectTask", "ProjectBudget", "ProcurementContract",
                      "ProjectInvoice", "ProjectExpense", "ProjectCommitment", "ProjectResource",
                      "ProjectAttachment"):
            self.assertIn(model, content)

    def test_v8_service_sources_parse(self):
        for rel in ("app/services/v8_service.py", "app/services/document_service.py", "app/ui/main_window.py"):
            ast.parse((ROOT / rel).read_text(encoding="utf-8"), filename=rel)

if __name__ == "__main__":
    unittest.main()
