import ast
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class TestProjectStructure(unittest.TestCase):
    def test_required_directories(self):
        for name in ("app", "app/models", "app/services", "app/ui", "tests", "scripts", "docs"):
            self.assertTrue((ROOT / name).exists(), name)

    def test_python_syntax(self):
        for path in ROOT.rglob("*.py"):
            if ".venv" in path.parts:
                continue
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def test_no_secrets_in_env_example(self):
        content = (ROOT / ".env.example").read_text(encoding="utf-8")
        self.assertNotIn("password=123", content.lower())
        self.assertIn("INITIAL_ADMIN_PASSWORD=", content)
        self.assertTrue(content.rstrip().endswith("INITIAL_ADMIN_PASSWORD="))

if __name__ == "__main__":
    unittest.main()
