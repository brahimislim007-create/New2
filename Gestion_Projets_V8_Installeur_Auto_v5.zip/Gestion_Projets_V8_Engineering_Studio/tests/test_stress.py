
import os
import sys
import time
import threading
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

try:
    from app.resilience import task_queue, retry, system_metrics, logger
    IMPORT_ERROR = None
except Exception as exc:
    IMPORT_ERROR = exc

class TestStressAndResilience(unittest.TestCase):
    def setUp(self):
        if IMPORT_ERROR:
            self.skipTest(f"Dépendance indisponible: {IMPORT_ERROR}")

    def test_retry_mechanism(self):
        state = {"calls": 0}

        @retry(attempts=3, delay=0.01, backoff=1, exceptions=(RuntimeError,))
        def unstable_operation():
            state["calls"] += 1
            if state["calls"] < 3:
                raise RuntimeError("temporary failure")
            return "OK"

        self.assertEqual(unstable_operation(), "OK")
        self.assertEqual(state["calls"], 3)

    def test_queue_burst(self):
        total = 300
        futures = []
        counter = {"value": 0}
        lock = threading.Lock()

        def work(n):
            with lock:
                counter["value"] += 1
            return n * n

        start = time.perf_counter()
        for i in range(total):
            futures.append(task_queue.submit(work, i))

        results = [f.result(timeout=15) for f in futures]
        elapsed = time.perf_counter() - start

        self.assertEqual(counter["value"], total)
        self.assertEqual(results[0], 0)
        self.assertEqual(results[-1], (total - 1) ** 2)
        self.assertLess(elapsed, 15)

    def test_monitoring_metrics(self):
        m = system_metrics()
        self.assertIn("queue_size", m)
        self.assertGreaterEqual(m["queue_size"], 0)

if __name__ == "__main__":
    unittest.main(verbosity=2)
