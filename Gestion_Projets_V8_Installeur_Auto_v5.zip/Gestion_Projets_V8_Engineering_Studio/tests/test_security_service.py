import os
os.environ.setdefault("DATABASE_URL", "sqlite+pysqlite:///:memory:")

import unittest
from app.services.security_service import hash_password, verify_password

class TestPasswordSecurity(unittest.TestCase):
    def test_hash_and_verify(self):
        password = "MotDePasseTresSolide123!"
        stored = hash_password(password)
        self.assertNotEqual(stored, password)
        self.assertTrue(verify_password(password, stored))
        self.assertFalse(verify_password("wrong-password", stored))

    def test_short_password_rejected(self):
        with self.assertRaises(ValueError):
            hash_password("court")

if __name__ == "__main__":
    unittest.main()
