import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TestProjectStructure(unittest.TestCase):
    def test_required_files(self):
        required = [
            "main.py",
            "app/database.py",
            "app/models/models.py",
            "app/services/project_service.py",
            "app/ui/main_window.py",
            "app/reports/report_service.py",
        ]
        for name in required:
            self.assertTrue((ROOT / name).exists(), name)

if __name__ == "__main__":
    unittest.main()
