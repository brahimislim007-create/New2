"""Tests de logique métier sur une vraie base SQLite temporaire.

Nécessite SQLAlchemy (pip install -r requirements.txt). Sont ignorés si la dépendance manque.
"""
import os
import tempfile
import unittest
from pathlib import Path

try:
    import sqlalchemy  # noqa: F401
    HAS_SQLALCHEMY = True
except ImportError:
    HAS_SQLALCHEMY = False

ROOT = Path(__file__).resolve().parents[1]
_TMP = tempfile.mkdtemp(prefix="gp_test_")

if HAS_SQLALCHEMY:
    os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(_TMP) / "test.db").replace("\\", "/")
    from sqlalchemy import text
    from app.database import Base, engine
    import app.models  # noqa: F401
    from app.services import v8_service, project_service, security_service, document_service
    from app.services.security_service import MAX_ATTEMPTS
    from app.migrations import ensure_additive_columns
    from app.reports.report_service import _safe_cell
    Base.metadata.create_all(engine)


@unittest.skipUnless(HAS_SQLALCHEMY, "SQLAlchemy non installé")
class BusinessLogicTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.project = project_service.create_project("T-001", "Projet test", progress=0)

    def test_zero_amount_is_accepted(self):
        item = v8_service.add_record("budgets", self.project.id, label="Lot 0", amount=0, currency="TND")
        self.assertEqual(float(item.amount), 0.0)

    def test_negative_amount_rejected(self):
        with self.assertRaises(ValueError):
            v8_service.add_record("expenses", self.project.id, category="X", description="Y", amount=-5)

    def test_missing_required_amount_rejected(self):
        with self.assertRaises(ValueError):
            v8_service.add_record("budgets", self.project.id, label="Sans montant", amount=None)

    def test_unknown_currency_rejected(self):
        with self.assertRaises(ValueError):
            v8_service.add_record("budgets", self.project.id, label="Devise", amount=1, currency="XYZ")

    def test_finance_totals_are_kept_per_currency(self):
        before = v8_service.finance_summary(self.project.id)["budgets"]
        v8_service.add_record("budgets", self.project.id, label="TND", amount=100, currency="TND")
        v8_service.add_record("budgets", self.project.id, label="EUR", amount=50, currency="EUR")
        after = v8_service.finance_summary(self.project.id)["budgets"]
        self.assertAlmostEqual(after.get("TND", 0) - before.get("TND", 0), 100)
        self.assertAlmostEqual(after.get("EUR", 0) - before.get("EUR", 0), 50)

    def test_status_follows_progress(self):
        p = project_service.create_project("T-002", "Avancement", progress=0)
        self.assertEqual(p.status, "Nouveau")
        p = v8_service.update_project(p.id, progress=100)
        self.assertEqual(p.status, "Terminé")
        p = v8_service.update_project(p.id, progress=40)
        self.assertEqual(p.status, "En cours")
        p = v8_service.update_project(p.id, status="Suspendu")
        self.assertEqual(p.status, "Suspendu")

    def test_date_order_checked_against_stored_values(self):
        p = project_service.create_project("T-003", "Dates", start_date="2026-05-10")
        with self.assertRaises(ValueError):
            v8_service.update_project(p.id, end_date="2026-05-01")  # fin avant le début déjà stocké

    def test_dates_are_saved_with_creation(self):
        p = project_service.create_project("T-004", "Dates création", start_date="2026-01-01", end_date="2026-12-31")
        self.assertEqual(str(p.start_date), "2026-01-01")
        self.assertEqual(str(p.end_date), "2026-12-31")

    def test_empty_code_rejected(self):
        # Erreur de saisie : elle doit remonter directement (sans nouvelle tentative).
        with self.assertRaises(ValueError):
            project_service.create_project("", "Sans code")

    def test_attachment_to_missing_project_leaves_no_file(self):
        src = Path(_TMP) / "note.txt"
        src.write_text("contenu", encoding="utf-8")
        storage = document_service._storage_root() / "project_999999"
        with self.assertRaises(ValueError):
            document_service.attach_file(999999, src)
        self.assertFalse(storage.exists() and any(storage.iterdir()))

    def test_excel_formula_is_neutralised(self):
        self.assertEqual(_safe_cell("=HYPERLINK(\"x\")"), "'=HYPERLINK(\"x\")")
        self.assertEqual(_safe_cell("Pont R&D"), "Pont R&D")
        self.assertEqual(_safe_cell(12), 12)

    def test_login_lockout_survives_correct_password(self):
        security_service.create_user("lockuser", "MotDePasse123!", "USER")
        for _ in range(MAX_ATTEMPTS):
            self.assertIsNone(security_service.authenticate("lockuser", "mauvais-mot-de-passe"))
        self.assertIsNone(security_service.authenticate("lockuser", "MotDePasse123!"))

    def test_login_succeeds_before_lockout(self):
        security_service.create_user("okuser", "MotDePasse123!", "USER")
        self.assertIsNotNone(security_service.authenticate("okuser", "MotDePasse123!"))


@unittest.skipUnless(HAS_SQLALCHEMY, "SQLAlchemy non installé")
class AdditiveMigrationTests(unittest.TestCase):

    def test_missing_columns_are_added_and_data_kept(self):
        db_file = Path(_TMP) / "v7.db"
        from sqlalchemy import create_engine as ce
        old = ce("sqlite:///" + str(db_file).replace("\\", "/"))
        with old.begin() as conn:
            conn.execute(text("CREATE TABLE projects (id INTEGER PRIMARY KEY, code VARCHAR(50), name VARCHAR(250))"))
            conn.execute(text("INSERT INTO projects (id, code, name) VALUES (1, 'V7-1', 'Ancien projet')"))
        added = ensure_additive_columns(old, Base)
        self.assertIn("projects.progress", added)
        self.assertIn("projects.start_date", added)
        with old.connect() as conn:
            row = conn.execute(text("SELECT code, name FROM projects WHERE id = 1")).one()
        self.assertEqual(tuple(row), ("V7-1", "Ancien projet"))
        # Deuxième passage : rien à ajouter.
        self.assertEqual(ensure_additive_columns(old, Base), [])


if __name__ == "__main__":
    unittest.main()
