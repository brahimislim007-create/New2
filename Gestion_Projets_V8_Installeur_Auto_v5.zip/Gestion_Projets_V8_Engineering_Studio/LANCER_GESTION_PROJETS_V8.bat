@echo off
setlocal
cd /d "%~dp0"
title Gestion Projets V8 Engineering Studio
set "PY="
call :find_python
if not defined PY (
  echo Python 3.12 ou 3.13 64 bits est necessaire pour Gestion Projets V8.
  echo Installez Python 3.12 ou 3.13 ^(version Windows x86-64^), puis relancez INSTALLER_V8.bat.
  pause
  exit /b 1
)
%PY% main.py
if errorlevel 1 pause
exit /b 0

:find_python
REM Ordre : .venv du projet, puis py -3.13, puis py -3.12, puis python. Python 64 bits uniquement.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
  if not errorlevel 1 (
    set "PY=.venv\Scripts\python.exe"
    goto :eof
  )
)
py -3.13 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.13"
  goto :eof
)
py -3.12 -c "import struct,sys; sys.exit(0 if struct.calcsize('P')==8 else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.12"
  goto :eof
)
python -c "import struct,sys; sys.exit(0 if (sys.version_info[:2] in ((3,12),(3,13)) and struct.calcsize('P')==8) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=python"
goto :eof
