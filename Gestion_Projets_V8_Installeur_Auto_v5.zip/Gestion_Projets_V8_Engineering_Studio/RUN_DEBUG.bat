@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Environnement .venv absent. Executez setup_visual_studio.bat.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python scripts\verify_code.py
if errorlevel 1 pause & exit /b 1
python main.py
pause
