@echo off
call QUALITE_ET_TESTS.bat
