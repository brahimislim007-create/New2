@echo off
setlocal
cd /d "%~dp0\.."
call INSTALLER_V8.bat
