﻿$ErrorActionPreference = "Continue"
Write-Host "=== ANALYSE SYSTEME - GESTION PROJETS V7 ==="
Write-Host "Windows: $([Environment]::OSVersion.VersionString)"
Write-Host ""

foreach ($cmd in @("python","py","winget")) {
  $found = Get-Command $cmd -ErrorAction SilentlyContinue
  if ($found) { Write-Host "[OK] $cmd -> $($found.Source)" }
  else { Write-Host "[MANQUANT] $cmd" }
}

$inno = @(
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
  "${env:ProgramFiles}\Inno Setup 6\ISCC.exe",
  "${env:LOCALAPPDATA}\Programs\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($inno) { Write-Host "[OK] Inno Setup -> $inno" }
else { Write-Host "[MANQUANT] Inno Setup / ISCC.exe" }

if (Test-Path ".env") { Write-Host "[OK] .env present" }
else { Write-Host "[ATTENTION] .env absent - PostgreSQL doit etre configure avant lancement." }

Write-Host ""
Write-Host "=== FIN ANALYSE ==="
