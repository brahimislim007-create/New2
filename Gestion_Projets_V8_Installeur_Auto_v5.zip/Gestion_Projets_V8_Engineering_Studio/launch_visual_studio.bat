@echo off
cd /d "%~dp0"
echo ==========================================
echo  Gestion Projets V8 - Visual Studio
echo ==========================================
where devenv >nul 2>nul
if errorlevel 1 (
  echo Visual Studio Community n'est pas detecte dans PATH.
  echo Ouvrez ce dossier directement avec Visual Studio Community.
  pause
  exit /b 1
)
devenv Gestion_Projets_V8_Engineering_Studio.sln
