import sys
from PySide6.QtWidgets import QApplication, QMessageBox

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Gestion Projets V8 Engineering Studio")

    from app.config import is_64bit_python, read_text_auto, resource_directory
    if not is_64bit_python():
        QMessageBox.critical(None, "Python 32 bits non pris en charge",
            "Ce programme doit être exécuté avec Python 64 bits (Windows x64).\n"
            "Installez Python 3.12 ou 3.13 en version 64 bits, puis relancez.")
        return 1

    try:
        qss = resource_directory() / "app" / "ui" / "ribbon.qss"
        if qss.exists():
            app.setStyleSheet(read_text_auto(qss))
    except Exception:
        pass
    try:
        from app.database import Base, engine
        import app.models
        from app.migrations import ensure_additive_columns
        from app.services.security_service import ensure_initial_admin
        from app.ui.login_dialog import LoginDialog
        from app.ui.main_window import MainWindow

        Base.metadata.create_all(engine)
        ensure_additive_columns(engine, Base)
        ensure_initial_admin()

        login = LoginDialog()
        if login.exec() != LoginDialog.Accepted:
            return 0

        window = MainWindow(current_user=login.user)
        window.show()
        return app.exec()
    except Exception as e:
        QMessageBox.critical(None, "Erreur de démarrage",
            f"Le programme ne peut pas démarrer.\n\n{type(e).__name__}: {e}\n\n"
            "Vérifiez .env, PostgreSQL et les dépendances.")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
