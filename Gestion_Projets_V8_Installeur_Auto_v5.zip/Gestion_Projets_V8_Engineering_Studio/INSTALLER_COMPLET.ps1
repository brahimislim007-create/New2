﻿<#
  GESTION PROJETS V8 - INSTALLATION AUTOMATIQUE (Windows 64 bits)

  Étapes :
    1. Analyse de tous les fichiers du projet (inventaire par type, syntaxe Python, structure).
    2. Vérification de Python 64 bits (3.12 ou 3.13) ; sinon arrêt avec explication.
    3. Création de l'environnement .venv et installation des dépendances.
    4. Tests automatiques ; l'installation s'arrête si un test échoue.
    5. Configuration .env (copie du modèle, ouverture pour saisie) et contrôle de DATABASE_URL.
    6. Raccourcis sur le Bureau et dans le menu Démarrer.
    7. Rapport complet dans logs\rapport_installation.txt.

  Lancer via INSTALLER_COMPLET.bat (double-clic).
#>
# "Continue" : pip et Python écrivent des avertissements sur stderr, ce qui arrêterait
# un script en mode "Stop" (Windows PowerShell 5.1). Chaque étape vérifie $LASTEXITCODE.
$ErrorActionPreference = "Continue"
Set-Location -LiteralPath $PSScriptRoot
$AppName = "Gestion Projets V8"
$LogDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Report = Join-Path $LogDir "rapport_installation.txt"
Set-Content -Path $Report -Value "Rapport d'installation - $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')" -Encoding UTF8

function Log([string]$Message) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
    Write-Host $line
    Add-Content -Path $Report -Value $line -Encoding UTF8
}

function Fail([string]$Message) {
    Log "ERREUR : $Message"
    Log "Consultez le rapport : $Report"
    Read-Host "Appuyez sur Entrée pour fermer" | Out-Null
    exit 1
}

function Get-Python64 {
    $candidates = @(
        @{ Exe = "py"; Args = @("-3.13") },
        @{ Exe = "py"; Args = @("-3.12") },
        @{ Exe = "python"; Args = @() }
    )
    foreach ($c in $candidates) {
        try {
            $out = & $c.Exe @($c.Args) -c "import struct,sys; print(struct.calcsize('P')*8, sys.version_info[0], sys.version_info[1])" 2>$null
            if ($LASTEXITCODE -eq 0 -and "$out" -match '^64 3 1[23]\s*$') { return $c }
        } catch { }
    }
    return $null
}

# ---------------------------------------------------------------- 1. Analyse des fichiers
Log "=== 1. Analyse du projet ==="
$allFiles = Get-ChildItem -Recurse -File | Where-Object { $_.FullName -notmatch '\\(\.venv|__pycache__|\.git|logs|data|reports|backups|dist|build)\\' }
Log "Fichiers trouvés : $($allFiles.Count)"
$allFiles | Group-Object { if ($_.Extension) { $_.Extension.ToLower() } else { "(sans extension)" } } |
    Sort-Object Count -Descending | ForEach-Object { Log ("  {0,-16} {1,5}" -f $_.Name, $_.Count) }
$missing = @("main.py", "requirements.txt", ".env.example", "app\database.py", "app\ui\main_window.py") |
    Where-Object { -not (Test-Path (Join-Path $PSScriptRoot $_)) }
if ($missing) { Fail ("Fichiers essentiels manquants : " + ($missing -join ", ")) }
Log "Fichiers essentiels : présents."

# ---------------------------------------------------------------- 2. Python 64 bits
Log "=== 2. Vérification de Python 64 bits ==="
$py = Get-Python64
if (-not $py) {
    Fail "Python 3.12 ou 3.13 en version 64 bits est introuvable. Installez-le depuis python.org (Windows x86-64), cochez « Add python.exe to PATH », puis relancez."
}
$pyLabel = (($py.Exe, $py.Args) | ForEach-Object { $_ }) -join " "
Log "Python utilisé : $pyLabel (64 bits)"

# ---------------------------------------------------------------- 3. Environnement et dépendances
Log "=== 3. Environnement .venv et dépendances ==="
$venvPy = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    & $py.Exe @($py.Args) -m venv (Join-Path $PSScriptRoot ".venv") *>> $Report
    if ($LASTEXITCODE -ne 0) { Fail "Création de l'environnement .venv impossible (voir le rapport)." }
    Log ".venv créé."
} else { Log ".venv existant réutilisé." }
& $venvPy -m pip install --upgrade pip *>> $Report
& $venvPy -m pip install -r (Join-Path $PSScriptRoot "requirements.txt") *>> $Report
if ($LASTEXITCODE -ne 0) { Fail "Installation des dépendances impossible (vérifiez la connexion Internet et le rapport)." }
Log "Dépendances installées."

# ---------------------------------------------------------------- 4. Vérifications et tests
Log "=== 4. Vérification du code et tests ==="
& $venvPy (Join-Path $PSScriptRoot "scripts\verify_code.py") *>> $Report
if ($LASTEXITCODE -ne 0) { Fail "Vérification du code échouée (voir le rapport)." }
Log "Vérification du code : OK."
& $venvPy -m pytest (Join-Path $PSScriptRoot "tests") -q *>> $Report
if ($LASTEXITCODE -ne 0) { Fail "Des tests ont échoué. Le programme n'a pas été installé. Voir le rapport." }
Log "Tests : OK."

# ---------------------------------------------------------------- 5. Configuration .env
Log "=== 5. Configuration (.env) ==="
$envFile = Join-Path $PSScriptRoot ".env"
if (-not (Test-Path $envFile)) {
    Copy-Item (Join-Path $PSScriptRoot ".env.example") $envFile
    if (-not (Test-Path $envFile)) { Fail "Impossible de créer .env à partir du modèle." }
    Log "Fichier .env créé à partir du modèle. Renseignez-le puis enregistrez."
    Start-Process notepad.exe -ArgumentList $envFile -Wait
}
$envText = Get-Content -Raw -Encoding UTF8 $envFile
if (-not $envText) { $envText = "" }
if ($envText -notmatch 'DATABASE_URL=\S*://' -or $envText -match 'CHANGE_ME') {
    Log "AVERTISSEMENT : DATABASE_URL semble incomplet ou contient CHANGE_ME. Corrigez .env avant le premier lancement."
} else { Log "DATABASE_URL renseigné." }
if ($envText -notmatch 'INITIAL_ADMIN_PASSWORD=.{10,}') {
    Log "AVERTISSEMENT : INITIAL_ADMIN_PASSWORD absent ou trop court (10 caractères minimum)."
}

# ---------------------------------------------------------------- 6. Raccourcis
Log "=== 6. Raccourcis ==="
$launcher = Join-Path $PSScriptRoot "LANCER_GESTION_PROJETS_V8.bat"
$shell = New-Object -ComObject WScript.Shell
$targets = @(
    [Environment]::GetFolderPath("Desktop"),
    (Join-Path ([Environment]::GetFolderPath("Programs")) $AppName)
)
foreach ($dir in $targets) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $lnk = $shell.CreateShortcut((Join-Path $dir "$AppName.lnk"))
    $lnk.TargetPath = $launcher
    $lnk.WorkingDirectory = $PSScriptRoot
    $lnk.Description = "Gestion Projets V8 Engineering Studio"
    $lnk.Save()
    Log "Raccourci créé : $dir"
}

# ---------------------------------------------------------------- 7. Fin
Log "=== Installation terminée ==="
Log "Lancez « $AppName » depuis le Bureau ou le menu Démarrer."
Log "Rapport complet : $Report"
Start-Process notepad.exe -ArgumentList $Report
Read-Host "Appuyez sur Entrée pour fermer" | Out-Null
