@echo off
REM Installation automatique de Gestion Projets V8 (double-clic).
REM Analyse le projet, verifie Python 64 bits, installe les dependances, lance les tests,
REM configure .env et cree les raccourcis. Rapport : logsapport_installation.txt
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER_COMPLET.ps1"
exit /b %errorlevel%
